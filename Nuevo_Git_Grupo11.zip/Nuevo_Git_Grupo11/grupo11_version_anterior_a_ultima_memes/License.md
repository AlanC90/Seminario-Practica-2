# Licencia Apache, Versión 2.0

### Derechos de autor

Copyright (c) 2023, Alan Carreras, Lucas Figari, Mateo Andrés Carusotti, Valentin Ezequiel Di Santo

### Agradecimientos

Queremos agradecer a las siguientes personas por sus valiosas contribuciones a este proyecto:

- Agustin Ignacio Genoves (https://gitlab.catedras.linti.unlp.edu.ar/agustingenoves)
- Ariadna Belén Aspitia (https://gitlab.catedras.linti.unlp.edu.ar/ariaspitia)
- Claudia Banchoff (https://gitlab.catedras.linti.unlp.edu.ar/cbanchoff)
- Eliana Sofia Martin (https://gitlab.catedras.linti.unlp.edu.ar/smartin)
- Facundo Catriel Diaz Gira (https://gitlab.catedras.linti.unlp.edu.ar/FaacuuDiaz)
- Federico Emmanuel Otaran (https://gitlab.catedras.linti.unlp.edu.ar/fedeotaran)
- Fernando Esteban Mariano López (https://gitlab.catedras.linti.unlp.edu.ar/lopez)
- Juan Manuel Fernández (https://gitlab.catedras.linti.unlp.edu.ar/juanfernandez)
- Juan Manuel Fazzano (https://gitlab.catedras.linti.unlp.edu.ar/juanmafazzano)
- Josue Franchesco Carrera Quinde (https://gitlab.catedras.linti.unlp.edu.ar/josuecarrera788)
- Lucas Chiacchio (https://gitlab.catedras.linti.unlp.edu.ar/arnolchacho)
- Lucas Di Cunzolo (https://gitlab.catedras.linti.unlp.edu.ar/lucasdicunzolo)
- Marco Cristofano (https://gitlab.catedras.linti.unlp.edu.ar/mcristofano)
- Maria Emilia Corrons (https://gitlab.catedras.linti.unlp.edu.ar/maemco)
- Simón Palacios (https://gitlab.catedras.linti.unlp.edu.ar/palaciossimon6)
- Ulises Martin Cura Jáuregui (https://gitlab.catedras.linti.unlp.edu.ar/ucuraj)

Los autores agradecen también a la Facultad de Informática de la Universidad Nacional de La Plata por la oportunidad de trabajar en este proyecto.

### Licencia

Este software se distribuye bajo la Licencia Apache, Versión 2.0 (la "Licencia"); no puede utilizar este archivo excepto en cumplimiento con la Licencia. Puede obtener una copia de la Licencia en:

http://www.apache.org/licenses/LICENSE-2.0

A menos que lo requiera la ley aplicable o se acuerde por escrito, el software distribuido bajo la Licencia se distribuye "TAL CUAL", SIN GARANTÍAS O CONDICIONES DE NINGÚN TIPO, ya sean expresas o implícitas. Consulte la Licencia para el idioma específico que rige los permisos y limitaciones bajo la Licencia.

# Protección de desarrolladores y usuarios

Es importante destacar que la licencia de software también proporciona protección tanto para los desarrolladores como para los usuarios. Los desarrolladores están protegidos de cualquier responsabilidad por los posibles daños que el software pueda causar. Por otro lado, los usuarios tienen derecho a utilizar, modificar y distribuir el software de acuerdo con los términos y condiciones establecidos en la licencia.
