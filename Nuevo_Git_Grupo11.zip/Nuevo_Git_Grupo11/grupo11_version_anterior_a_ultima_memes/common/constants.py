import PySimpleGUI as sg
import os

#Pantalla.
ancho_pantalla, alto_pantalla = sg.Window.get_screen_size()

ancho_window = int(ancho_pantalla * 0.5)
alto_window = int(alto_pantalla * 0.8)
#alto_window = int(alto_pantalla * 0.6)

#Predefinir tamaño de elementos y fuente. 
H1_SIZE = 20      #tamanio de titulo
TEXT_SIZE = 12    #tamanio de texto.

tema = sg.theme("DarkTeal6")
#-Setear valores generales o globales. 
sg.set_options(tema, element_size=(30, 1), font=("Comic Sans MS",TEXT_SIZE))


#Direcciones.
directorio_base =os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dir_avatar_default = os.path.join(directorio_base,"src","images","usuarios","default")
dir_collages = os.path.join(directorio_base,"src","images","collages")
dir_memes = os.path.join(directorio_base,"src","images","memes")

#nuevo.
dir_fonts = os.path.join(directorio_base,"fonts")


#ruta_archivo_log_sistema= os.path.join(directorio_base, "src", "common")
ruta_archivo_log_sistema= os.path.join(directorio_base, "common", "logs_sistema.csv")
