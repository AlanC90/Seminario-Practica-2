import os
import json
from PIL import Image, ImageTk
from common.constants import directorio_base
from common.constants import dir_avatar_default
from common.constants import dir_collages
from common.constants import dir_memes
from common.constants import ancho_window, alto_window
from common.constants import H1_SIZE
from common.modulos import comprobar_campos_completos, comprobar_formato_correo, lectura_json, escritura_json

#nuevo.
from config.paths import convertir_para_guardar

import PySimpleGUI as sg

print(directorio_base)
extensiones = [ ("Archivos png", ".png")] #extensiones para imagenes
generos = ('Masculino','Femenino','Otro')   #tupla con los generos 
dir_avatar = os.path.join(dir_avatar_default, "default0.png")  #direccion del avatar a mostrar

# -------------------FUNCIONES--------------------------------------------------------

def comprobacion_completa(nick_usuario, nombre, genero, correo, edad):
    return((comprobar_campos_completos(nick_usuario, nombre, genero, correo, edad) and comprobar_formato_correo(correo)) and nick_es_unico_creacion(nick_usuario))
     



def nick_es_unico_creacion(nick_usuario):
    """funcion que recorre el archivo de usuarios registrados para asegurarse de que el nick ingresado no este repetido. Recibe como parametro el nick del usuario y retorna True o False"""
    print("comprobando nick unico")
    
    x = True   #boolean que determina si se encuentra el nick repetido o es unico--------
    pos = 0
    ruta_archivo = os.path.join(directorio_base,"src","data","usuarios.json")  
    datos = lectura_json(ruta_archivo)                                             
    while x and (pos < len(datos)):     #se trabaja con el archivo-----     
        if datos[pos]['nick'] == nick_usuario:
            x = False
            sg.popup("El nick ingresado ya existe. Por favor ingrese otro.")
        else:
            pos += 1

    
    return x


def guardar_datos(nick_usuario, nombre_usuario, genero_usuario, correo_usuario, avatar_seleccionado, edad_usuario):
    """funcion que recibe parametros del usuario(nick,nombre,genero,correo,avatar,edad), y guarda los datos en un diccionario para almacenarlos finalmente en un archivo.json"""    
    print("comenzar funcion guardar_datos")

    #nuevo.
    avatar_seleccionado = convertir_para_guardar(avatar_seleccionado, directorio_base)

    se_pudo_guardar = False                 
    if comprobacion_completa(nick_usuario, nombre_usuario, genero_usuario, correo_usuario, edad_usuario):
        
        dicc_datos = {"nick":nick_usuario,                       #DICCIONARIO CON VALORES INGRESADOS
                    "nombre":nombre_usuario,
                    "genero":genero_usuario,
                    "correo":correo_usuario,
                    "edad":edad_usuario,
                    "direc_avatar":avatar_seleccionado
                    }
        
        ruta_archivo = os.path.join(directorio_base,"src","data","usuarios.json") 
        
        datos = lectura_json(ruta_archivo)
        datos.append(dicc_datos)
        
        se_pudo_guardar = escritura_json(datos, ruta_archivo)
    
                       
    return se_pudo_guardar
            

        
    
#---------------------------LAYOUT-----------------------------

def nuevo_perfil():
    """funcion que crea un nuevo usuario con Nombre, Apellido y foto de perfil, y se almacena en un archivo json."""
    
    layout = [  
                [sg.Text('Completa el formulario', font=(H1_SIZE), justification='center', key= '-FORM-')], #TEXTO DE COMPLETAR FORMULARIO      
                [sg.Image(source= dir_avatar, size= (180,180), subsample= 2, key= '-AVATAR-')], #Imagen avatar
                [sg.FileBrowse('Cambiar avatar', enable_events= True, change_submits= True, initial_folder= dir_avatar_default, file_types= extensiones,key= '-BROWSE-'),],

                [sg.Column([ #columna que contiene los datos que deben procesarse
                    [sg.Text('Nick'), sg.InputText(key= '-NICK-'),],    #Nick a ingresar
                    [sg.Text('Nombre'), sg.InputText(key= '-NOMBRE-'),], #Apellido a ingresar
                    [sg.Text('Correo',), sg.InputText(key= '-CORREO_ELECTRONICO-')],
                    [sg.Text('Edad'), sg.InputText(key= '-EDAD-'),],    #Edad a ingresar
                    [sg.Text('Genero'), sg.Combo(generos, key= '-GENERO-', default_value="-Elegir-" ,readonly= True, ),]], justification="CENTER"    #menu desplegable para seleccionar genero
                       )
                  
                 ],  
                 [sg.Button("Guardar y finalizar", key= '-GUARDAR-'), sg.Button("Cancelar y salir", key= '-CANCELAR-')]


             ]
            
            
    
    window = sg.Window("UNLPImage-Crear Perfil",layout,size=(ancho_window,alto_window),element_justification= "center", resizable= True, finalize= True) #asigno los valores a la ventana
    window.set_min_size((ancho_window,alto_window)) #asigno el tamaño minimo de pantalla

#----------------PROGRAMA PRINCIPAL -------------------------------------------------------------------------------
 
    aux_avatar = dir_avatar    #variable de la ruta del avatar
    while True:
        event, value = window.read() 
        if event == sg.WIN_CLOSED:  
                sg.popup("Saliendo de la aplicacion")    
                exit()      
        
        else:
            if event == '-BROWSE-':         #boton para cambiar el avatar
                imagen = value['-BROWSE-']
                imagen_pil = Image.open(imagen)
                imagen_pil.thumbnail((180, 180))
                bio = ImageTk.PhotoImage(imagen_pil)
                aux_avatar = value['-BROWSE-']
                window['-AVATAR-'].update(data = bio, subsample=2)                



            elif event =='-GUARDAR-':       #boton de guardado
                nick_usuario = value['-NICK-']
                nombre_usuario = value['-NOMBRE-']
                genero_usuario = value['-GENERO-']
                correo_usuario = value['-CORREO_ELECTRONICO-']
                try:
                    edad_usuario = int(value['-EDAD-'])
                except ValueError:
                    sg.popup("La edad ingresada no es un número.")
                    
                else:
                    guardado = guardar_datos(nick_usuario, nombre_usuario, genero_usuario, correo_usuario, aux_avatar, edad_usuario)  #variable guardado de tipo bool corrobora si se pudo guardar los datos
                    if guardado:
                        sg.popup("El usuario fue creado exitosamente. Volviendo al inicio...")
                        break            #finaliza la creación de perfil
                
            elif event == '-CANCELAR-':  #cierra el programa al darle cancelar
                
                x = sg.PopupYesNo("¿Estás seguro que deseas salir sin guardar los cambios?", title="Cancelar Perfil")  
                if x == 'Yes':
                    break  

              

                   
    window.close()