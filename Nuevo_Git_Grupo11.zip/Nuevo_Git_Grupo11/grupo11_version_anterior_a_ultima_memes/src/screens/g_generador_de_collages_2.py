import PySimpleGUI as sg
import sys
import os
import csv
import json
from PIL import Image
from common.constants import ancho_window, alto_window
from common.constants import directorio_base

codificacion = sys.getdefaultencoding()
ruta_csv_imagenes= os.path.join(directorio_base,'src','data','datos_imagenes.csv')

def buscar_imagen (direc_imagen):
    """Funcion que busca si la imagen se encuentra en el archivo csv, y retorna 
       la imagen. Recibe como parametro la direccion de la imagen."""
    
    esta = False

    imagen_return = direc_imagen
    with open(ruta_csv_imagenes,"r",encoding= codificacion)as archi_imagen:
        datos = csv.DictReader(archi_imagen)
        for imagen in datos:
            if(imagen['direccion'] == direc_imagen ):
                esta = True
                imagen_return = imagen
                break
    return (esta,imagen_return) 

def crear_columna_uno():
    botones_seleccionar = []
    for indice in range(1, 4 ): #cantidad de imagenes seleccionada en la anterior pantallas
        botones_seleccionar.append(
            [sg.FileBrowse('Seleccionar Imagen',key = indice)]
        )
    columna_1 = [[
        sg.Column(
        [
            botones_seleccionar,
            [sg.Text('Título:')],
            [sg.Input(key= '-INPUT_TITULO-')]

        ]
        )
    ]]   
    
    return columna_1

def crear_columna_dos():
    columna_2 = [
    [
        sg.Column(
            [
                sg.Image()
            ]
        )
    ]
    ]
    return columna_2


def ejecutar_generador_collage_2():
    layout_superior = [
        sg.Text('Generar collage '),sg.Push(),sg.Button('Volver',key = '-VOLVER-')
    ]
    layout_medio = [
        crear_columna_uno(), crear_columna_dos()
    ]
    layout_inferior = [
        sg.Push(),sg.Button('Guardar',key = '-GUARDAR-')
    ]

    layout = [layout_superior,layout_medio,layout_inferior]

    window = sg.Window(layout)

    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED:
            exit()
        elif event == '-VOLVER-':
            
        elif event == '-GUARDAR-':
        
        elif type(event) == int:
            esta,imagen = buscar_imagen(values[event]) #probar si funciona values[event], sino crear los browser a mano.
            if esta:
                #actualizar el collage en la posicion correspondiente al browser
            else:
                sg.popup('Solo se puede usar imagenes etiquetadas')    
        window.close()

    