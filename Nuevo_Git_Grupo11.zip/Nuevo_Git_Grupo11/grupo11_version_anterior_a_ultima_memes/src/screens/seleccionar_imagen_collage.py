import PySimpleGUI as sg
import os
from common.constants import alto_window, ancho_window
from common.constants import directorio_base

#importar ejecutar el collage



def ejecutar_seleccionar_imagen_collage(usuario):
        disenio_uno = os.path.join(directorio_base,'src','images','disenios_collages','disenio_uno.png')
        disenio_dos = os.path.join(directorio_base,'src','images','disenios_collages','disenio_dos.png')
        disenio_tres = os.path.join(directorio_base,'src','images','disenios_collages','disenio_tres.png')
        disenio_cuatro = os.path.join(directorio_base,'src','images','disenios_collages','disenio_cuatro.png')

        layout_disenios = [
        sg.Button(image_source=disenio_uno,size=(50,50),key = '-UNO-'),
        sg.Button(image_source=disenio_dos,size=(50,50),key = '-DOS-'),
        sg.Button(image_source=disenio_tres,size=(50,50),key = '-TRES-'),
        sg.Button(image_source=disenio_cuatro,size=(50,50),key = '-CUATRO-')

        ]

        layout_superior = [
        sg.Text('Seleccionar diseño de collages'),sg.Push(),sg.Button('Volver',key= '-VOLVER-')

        ]

        layout = [
        [
            sg.Column(
                [
                    layout_superior,
                    layout_disenios
                ]
            )
        ]
        ]

        window = sg.Window(layout)

        while True:
            event,values = window.read()
            if event == sg.WIN_CLOSED:
                exit()
            elif event == '-VOLVER-':
                 break
            else:
                 #pasarle a la funcion el diseño 
                 print("") 
        window.close()           
