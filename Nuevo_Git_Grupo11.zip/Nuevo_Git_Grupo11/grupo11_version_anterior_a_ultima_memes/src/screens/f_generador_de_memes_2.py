# UNLPImage
# Pantalla 2 de generador_de_memes


# Importar modulos y constantes.
import os
import json
import shutil
import tempfile
import tkinter as tk
import PySimpleGUI as sg
from PIL import Image, ImageTk, ImageDraw, ImageFont
from common.constants import ancho_window, alto_window, directorio_base, H1_SIZE, TEXT_SIZE, dir_fonts




#Para pruebas.
def imprimir_variable(variable):
    print()
    print(f'{variable= }')  #Preguntar.
    print()



# Ruta de archivo de donde se obtiene valores de templates de memes. 
ruta_memes_templates= os.path.join(directorio_base, "common", "memes_templates.json")

with open(ruta_memes_templates, "r") as archivo_meme_templates:
    datos = json.load(archivo_meme_templates)


# Lista con nombres de imagenes.
lista_templates = []

for elem in datos:
    lista_templates.append(elem["image"])



# Para guardar imagen en archivo temporal. 
# (archivo_temporal = es ruta de archivo)
archivo_temporal = tempfile.NamedTemporaryFile(suffix=".jpg").name


# Tipos de archivo.
tipos_de_archivo = [("PNG", "*.png"), ("JPEG", "*.jpg"), ("All files (*.*)", "*.*")]




def limpiar_inputs(event, values, window):
    """limpiar_imputs

    Args:
        event (string): _description_
        values (dict): _description_
        window (sg.Window): _description_
    """

    match event:
        case "-BOTON_LIMPIAR_TXT_1-":
            window["-INPUT_TEXTO_1-"].update("")
            values["-INPUT_TEXTO_1-"] = ""
    
        case "-BOTON_LIMPIAR_TXT_2-":
            window["-INPUT_TEXTO_2-"].update("")
            values["-INPUT_TEXTO_2-"] = ""
    
        
        case "-BOTON_LIMPIAR_TXT_3-":
            window["-INPUT_TEXTO_3-"].update("")
            values["-INPUT_TEXTO_3-"] = ""
            
        
        case "-BOTON_LIMPIAR_TXT_4-":
            window["-INPUT_TEXTO_4-"].update("")    
            values["-INPUT_TEXTO_4-"] = ""

    #------------------------------#
    



def texto_en_imagen(values, event, window, dir_imagen, template_meme, tam_fuentes_default, tam_fuentes_modificable, indice_imagen, color_del_texto):      
    """aplicar_texto

    Args:
        values (dict): _description_
        event (string): _description_
        window (sg.window): _description_
        dir_imagen (string): _description_
        template_meme (dict): _description_
        tam_fuentes_default (tuple): _description_
        tam_fuentes_modificable (list): _description_
        indice_imagen (int): _description_
    """

    # Ruta y nombre de imagen.      
    archivo_imagen = dir_imagen    
    nombre_imagen= os.path.basename(template_meme["image"])    

    
    # Guardar valores de inputs en lista.
    textos_inputs= []    
    
    for elem in values:        
        if "INPUT" in elem:
            textos_inputs.append(values[elem])    
                         
    
    # Procesar imagen y agregar text_boxes.
    if archivo_imagen and os.path.exists(archivo_imagen):
        
        # Uso de archivo temporal.
        shutil.copy(archivo_imagen, archivo_temporal)        

        # Cargar imagen.
        imagen = Image.open(archivo_temporal) 
    

        # Crear objeto draw.
        draw = ImageDraw.Draw(imagen)                          
  
  
        # Agregar boxes de textos en imagen.
        for pos, elem in enumerate (template_meme["text_boxes"]): 
                
            # Area rectangulo.  Preguntar (!)
            rectangle_width= elem["bottom_right_x"] - elem["top_left_x"]            
            rectangle_height= elem["bottom_right_y"] - elem["top_left_y"]
            area_rectangle = rectangle_width * rectangle_height
            
            fuentes= os.path.join(dir_fonts, values['-SELECCIONAR_FUENTE-'])
            
            # Dibujar texto.                                 
            if event == f"-BOTON_LIMPIAR_TXT_{pos+1}-":                
                tam_fuentes_modificable[indice_imagen][pos] = tam_fuentes_default[indice_imagen][pos]  
                fuente = ImageFont.truetype(fuentes, size=tam_fuentes_default[indice_imagen][pos])   

            else:
                fuente = ImageFont.truetype(fuentes, size=tam_fuentes_modificable[indice_imagen][pos])                                                    
                                                                                               

            draw.text((elem["top_left_x"]+5, elem["top_left_y"]+5), text=textos_inputs[pos], font= fuente, align="center", fill=color_del_texto)                                                                                      

            # Area texto. Preguntar (!)              
            text_width, text_height = draw.textsize(text= textos_inputs[pos], font=fuente)                    
            area_text= text_width * text_height             
                        

            # Reducir tamanio de texto.            
            while ((area_text > area_rectangle) | (text_width > rectangle_width) | (text_height > rectangle_height)):                  
               tam_fuentes_modificable[indice_imagen][pos] -= 1
               
               fuente = ImageFont.truetype(fuentes, size=tam_fuentes_modificable[indice_imagen][pos])                                                    
               
               text_width, text_height = draw.textsize(text= textos_inputs[pos], font=fuente)                    
               area_text= text_width * text_height    
            
                                                                    
 
        # Para evitar error de RGBA en algunas imagenes.
        try:
            imagen.save(archivo_temporal)           
        except:                            
            rgb_image = imagen.convert('RGB')
            rgb_image.save(archivo_temporal)

                                      
        imagen.thumbnail(size=(325, 325))
        photo_img = ImageTk.PhotoImage(imagen)

        window['-IMAGEN-'].update(data=photo_img)

    #------------------------------#



def guardar_imagen(meme_base):
    """guardar_imagen

    Args:
        values (dict): _description_
        meme_base (string): _description_
    """

    dir_archivo_a_guardar = sg.popup_get_file("File", 
                                                    file_types= tipos_de_archivo, 
                                                    save_as=True,
                                                    no_window=True)
    
    
    if dir_archivo_a_guardar == meme_base:
        sg.popup_error(
            "No esta permitido sobreescribir la imagen original")
    else:        
        if dir_archivo_a_guardar:             
            shutil.copy(archivo_temporal, dir_archivo_a_guardar)            
            sg.popup(f"Guardado: {dir_archivo_a_guardar}")


    #------------------------------#



def colores_oscuros(color):
    # Calcula la luminosidad del color
    luminosidad = (0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]) / 255

    # Define un limite para considerar un color como oscuro
    limite = 0.4

    return luminosidad < limite

    #------------------------------#

def crear_text_boxes(cant_boxes):         
    """crear_text_boxes

    Args:
        cant (int): _description_

    Returns:
        list: _description_
    """
    lineas_por_text_box= 3

    if cant_boxes > 2:
        lineas_por_text_box = 2

    

    lista_gral=[]

    for i in range(cant_boxes):        
        lista_bloque=[]
        
        lista_titulo_text=[]   
        lista_multiline_text=[]     

        lista_titulo_text.append(sg.Text(f"Texto {i+1}:",
                                             pad=((0,0), (0, 5)), 
                                             font = ("Comic Sans MS", TEXT_SIZE), 
                                             key = f"-TEXTO_{i+1}-"))
        
        lista_titulo_text.append(sg.Button("!", size=(2,1), tooltip="Sugerencia", font=("Comic Sans MS", 10), key='-AYUDA_BOTON-'))
                     
        lista_multiline_text.append(sg.Multiline(size=(20, lineas_por_text_box),
                                                  pad=((8,0),(0, 15)),                                                                                                   
                                                  enable_events= True,
                                                  tooltip="ayuda:seleccionar",
                                                  key=f"-INPUT_TEXTO_{i+1}-",
                                                  ))
                                          
        lista_multiline_text.append(sg.Button("Limpiar",
                                               pad=((10,0), (0, 0)),                                        
                                               font=('COMIC SANS MS', 10),
                                               key=f"-BOTON_LIMPIAR_TXT_{i+1}-",                                       
                                               enable_events=True))
        
        lista_bloque.append(lista_titulo_text)
        lista_bloque.append(lista_multiline_text)        

        lista_gral.append([sg.Column(lista_bloque)])


    return lista_gral
    
    #------------------------------#



def generar_layout(cant_text_boxes):        
    """_summary_

    Args:
        cant_text_boxes (int): _description_

    Returns:
        list: _description_
    """

    #Ventana.
    #-Componentes.    
    #Fila1.
    titulo = sg.Text("Generar meme",
                     size= (15,1),
                     pad=((0,0), (0, 20)), 
                     font = ("Comic Sans MS", H1_SIZE), 
                     key = "-TITULO_GENERAR_MEME-")
        
    volver = sg.Button("Volver", 
                       size= (10,1), 
                       pad=((0,0), (5, 20)),
                       font=("Comic Sans MS", TEXT_SIZE),
                       key = "-BOTON_VOLVER-")    
        
    #--------------------#

    
        

    #Fila2.   
    # columna_1 = sg.Column([[sg.Button("Seleccionar fuente",
    #                                   pad=((0,0), (0, 40)),
    #                                   font=("Comic Sans MS", TEXT_SIZE),
    #                                   key = "-BOTON_SELECCIONAR_FUENTE-")],                            
                                                                           
    #                        [sg.Column(crear_text_boxes(cant_text_boxes))]],
    #                        key="-COLUMNA_INPUTS_TEXT-")


    # Cargar tipografías del programa.
    tipos_de_fuentes = tuple(i for i in os.listdir(dir_fonts) if os.path.isfile(os.path.join(dir_fonts, i)))
    
    # [sg.Column([[sg.Text("Tipografia:")],
    #                                   [sg.Combo(tipos_de_fuentes,
    #                                  size:(10, 10),                                     
    #                                  readonly=True,
    #                                  default_value='Arial.ttf',
    #                                  key = "-SELECCIONAR_FUENTE-")]]),

    columna_1 = sg.Column([[sg.Text("Tipografia: ",
                                     pad= ((10,0), (0,5)),
                                     key="-TIPOGRAFIA-")],
                           [sg.Combo(tipos_de_fuentes,
                                     pad= ((16,0), (0,10)),
                                     enable_events=True,
                                     readonly=True,
                                     size=(10,8),
                                     default_value='Arial.ttf',
                                     font=("Comic Sans MS", 10),
                                     key = "-SELECCIONAR_FUENTE-")],

                            [sg.Text("Color de texto: ",
                                     pad= ((10,0), (0,5)),
                                     key="-COLOR_DE_TEXTO-")],         
                            [sg.Button("Seleccionar", 
                                    button_color=('#ffffff', '#000000'),
                                    pad= ((16,0), (0,10)),
                                    border_width=1, 
                                    key='-SELECCIONAR_COLOR-',
                                    )],

                           [sg.Column(crear_text_boxes(cant_text_boxes))]],
                           key="-COLUMNA_INPUTS_TEXT-")



    columna_2 = sg.Column([[sg.Image(source= None,
                                     key= '-IMAGEN-')
                           ]
                          ],
                          key= '-PREVISUALIZACION-IMAGEN-')          

    
    #--------------------#



    #Fila 3.
    guardar =  sg.Button("Guardar",                     
                         pad=((0,0), (0, 0)), 
                         key= "-BOTON_GUARDAR-")    
    
    #--------------------#

    

    #layout a retornar.
    layout = [              
              [titulo, sg.Push(), volver], 

              [columna_1, sg.Push(), columna_2],               
             
              [sg.Push(), guardar]

             ]


    return layout

    #------------------------------#



#-Ejecucion.
def ejecutar_generador_de_memes_2(dir_meme_base):               
    # Nombre de imagen base.
    nombre_imagen= os.path.basename(dir_meme_base)


     # Guardar copia de imagen base en archivo temporal.
    shutil.copy(dir_meme_base, archivo_temporal)  


    # Encontrar posicion de imagen en template .json.
    # Si no esta cargado su template, aplicacion termina.
    if nombre_imagen in lista_templates:
        indice_imagen= lista_templates.index(nombre_imagen)
    else:
        indice_imagen= -1
        sg.popup("No se encontro el template de la imagen ingresada")        
        sg.popup_auto_close("Saliendo de la aplicacion", auto_close_duration=(5), auto_close=True)
        exit()
        
    

    # Cargar template de imagen.    
    template_meme_base_elegido = datos[indice_imagen]        
    
    cant_text_boxes= len(template_meme_base_elegido["text_boxes"])


    
    # Crear ventana.     
    titulo_ventana = "UNLPImage-Generador de memes"

    window = sg.Window(titulo_ventana, 
                       generar_layout(cant_text_boxes), 
                       size= (ancho_window, alto_window),
                       finalize=True,
                       resizable=True)


    # Establecer tamanio minimo de pantalla.
    window.set_min_size((ancho_window, alto_window))


    # Color predeterminado para textos.
    color_texto = '#000000'

    # Mostrar imagen base.
    imagen_a_mostrar = Image.open(dir_meme_base)

    
    # # -Reducir tamanio de imagen especifica.
    # if "spongebob_increasingly" in nombre_imagen:
    imagen_a_mostrar.thumbnail(size=(325, 325))

    
    # -Convertir a objeto PhotoImage.
    imagen_tk = ImageTk.PhotoImage(imagen_a_mostrar)

    # -Cargar y mostrar imagen.                            
    window['-IMAGEN-'].update( data= imagen_tk)                 


    # Fuentes predefinidas para cada meme base.   #Preguntar si se puede incluir en el template .json (!)
    tam_fuentes_default= ([50, 90], 
                          [42, 42],
                          [30, 30],
                          [50, 50],
                          [30],
                          [30, 30, 30, 30],
                          [30, 30, 30],
                          [26, 26])

    
    # Fuentes modificables en ejecucion de cada meme base.
    # (tamanios para pruebas, modificar para que queden bien definidos )
    tam_fuentes_modificable =[[50, 90], 
                              [42, 42],                               
                              [30, 30],
                              [50, 50], 
                              [30], 
                              [30, 30, 30, 30], 
                              [30, 30, 30], 
                              [28, 28]]



    #-Bloque while.
    while True:
        #Eventos y valores.
        event, values = window.read()             

                
        #Acciones segun casos.
        match event:            
            case sg.WIN_CLOSED:
                sg.popup("Saliendo de la aplicacion")
                exit()
            
            case "-BOTON_VOLVER-": 
                break
           
            case "-AYUDA_BOTON-":
                ayuda_text= "Sugerencia: Podes ubicar el texto donde quieras, \n utilizando la tecla espacio(spacebar), \n retroceso (backspace) y enter(salto de linea)"
                sg.popup(ayuda_text, title="UNLPImage dice:")

            case '-SELECCIONAR_COLOR-':
                # colors es una tupla de 2 valores (color RGB y color hexadecimal)
                colors = tk.colorchooser.askcolor(
                            parent= window['-SELECCIONAR_COLOR-'].ParentForm.TKroot, color=color_texto)
            
                # Guardo el color hexadecimal seleccionado.
                color_texto = colors[1]

                
                if color_texto is not None:
                    # Comprueba si el color de fondo del botón es una variante oscura
                    if colores_oscuros(colors[0]):
                        # Actualiza el botón con texto en blanco
                        window['-SELECCIONAR_COLOR-'].Update(button_color=("#ffffff", color_texto))
                    else:
                        # Actualiza el botón con texto en negro
                        window['-SELECCIONAR_COLOR-'].Update(button_color=("#000000", color_texto))
                
                
                texto_en_imagen(values, event, window, dir_meme_base, template_meme_base_elegido, tam_fuentes_default, tam_fuentes_modificable, indice_imagen, color_texto)
            


            case '-BOTON_LIMPIAR_TXT_1-' | '-BOTON_LIMPIAR_TXT_2-' | '-BOTON_LIMPIAR_TXT_3-' | '-BOTON_LIMPIAR_TXT_4-':
                limpiar_inputs(event, values, window)                                 
                #window.refresh()    #Preguntar si funciona al utilizarlo. (!)                 
                              
                texto_en_imagen(values, event, window, dir_meme_base, template_meme_base_elegido, tam_fuentes_default, tam_fuentes_modificable, indice_imagen, color_texto)            
                                                            
            
            case '-INPUT_TEXTO_1-' | '-INPUT_TEXTO_2-' | '-INPUT_TEXTO_3-' | '-INPUT_TEXTO_4-' | '-SELECCIONAR_FUENTE-' :  #Preguntar (!)
                
                texto_en_imagen(values, event, window, dir_meme_base, template_meme_base_elegido, tam_fuentes_default, tam_fuentes_modificable, indice_imagen, color_texto)            
           

            case '-BOTON_GUARDAR-':                
                guardar_imagen(dir_meme_base)                

                                         

    #-Cerrar ventana.
    window.close()

    #------------------------------#
