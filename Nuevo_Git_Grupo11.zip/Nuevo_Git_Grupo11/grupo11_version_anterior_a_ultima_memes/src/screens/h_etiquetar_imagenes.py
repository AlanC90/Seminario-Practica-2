#UNLPImage
#Etiquetar Imagenes

#importar modulos y constantes.

import os
import csv
import json
import sys
import PySimpleGUI as sg
from datetime import datetime
from PIL import Image, ImageTk
from common.constants import directorio_base, dir_avatar_default
from common.constants import ancho_window, alto_window

#--------------------#


#Inicializaciones.
codificacion = sys.getdefaultencoding()

dir_avatar = os.path.join(dir_avatar_default,"default0.png")

ruta_csv_imagenes= os.path.join(directorio_base,'src','data','datos_imagenes.csv')


#Timestamp.
timestamp = datetime.timestamp(datetime.now())
fecha_hora = datetime.fromtimestamp(timestamp)
fecha_hora= fecha_hora.strftime("%d/%m/%Y, %H:%M:%S")

#--------------------#


#Funciones.--------------------------------------------------------

def comprobar_descripcion(descripcion):
    """funcion que recibe la descripcion como parametro y retorna un boolean indicando si respeta el formato de escritura"""

    es_correcto = False
    if not("" == descripcion) and not(" " == descripcion):
        if (len(descripcion)>50):
            sg.popup("La descripcion es demasiada extensa")
        else:
            print("campo de descripcion correcto.")
            es_correcto = True
    else:
        sg.popup("El campo de descripcion no debe estar vacio.")

    return es_correcto

#--------------------#

def resize_image(path_de_imagen_obtenida):
    """En esta función se escalan las imagenes cargadas desde el sg.Filebrowse al tamaño correspondiente
    para que se vean lo relativamente correctas en la pantalla.
    Para ésto se toman diferentes tamaños en consideración:
    Si la imagen tiene un tamaño mayor a 150 pixels o menor a 100 pixeles en cualquiera de sus lados,
    ésta se escalará a dichotamaño lo mejor posible.
    Manteniendo la relación de aspecto original de la imagen (relación entre la medida del lado más 
    largo y la del lado más corto.)"""

    with Image.open(path_de_imagen_obtenida) as imagen:
        # obtener las dimensiones de la imagen original
        ancho, alto = imagen.size

        # calcular el nuevo tamaño de la imagen
        max_ancho = 150
        max_alto = 150
        if ancho < 100 or alto < 100:
            max_ancho = 150
            max_alto = 150
        elif ancho > 150 or alto > 150:
            relacion_de_aspecto = ancho / alto
            if relacion_de_aspecto > 1:
                ancho = max_ancho
                alto = int(ancho / relacion_de_aspecto)
            else:
                alto = max_alto
                ancho = int(alto * relacion_de_aspecto)

        # redimensionar la imagen si es necesario
        if ancho != imagen.width or alto != imagen.height:
            imagen_redimensionada = imagen.resize((ancho, alto))
        else:
            imagen_redimensionada = imagen.copy()

        return imagen_redimensionada
    
#--------------------#

def buscar_imagen (direc_imagen):
    """Funcion que busca si la imagen se encuentra en el archivo csv, y retorna 
       la imagen. Recibe como parametro la direccion de la imagen."""
    
    esta = False

    imagen_return = direc_imagen
    with open(ruta_csv_imagenes,"r",encoding= codificacion)as archi_imagen:
        datos = csv.DictReader(archi_imagen)
        for imagen in datos:
            if(imagen['direccion'] == direc_imagen ):
                esta = True
                imagen_return = imagen
                break
    return (esta,imagen_return) 

    #--------------------#

def comprobar_descripcion(descripcion):
    """Funcion que recibe la descripcion de la imagen como parametro, y retorna un boolean
      indicando que es correcto si no esta vacio"""
    
    es_correcto = False
    if not("" == descripcion) and not(" " == descripcion):
        print("campo de descripcion correcto.")
        es_correcto = True
    else:
        sg.popup("El campo de descripcion no debe estar vacio.")
    
    return es_correcto 

    #--------------------#



def comprobar_tag(tag):
    """Funcion que recibe el tag de una imagen como parametro, y retorna un boolean 
       indicando que es correcto si no esta vacio, no tiene espacios en blanco y no 
       excede los 15 caracteres."""

    es_correcto = False
    
    if tag != "" and not( " " in tag) :
        if (len(tag)>13):
            sg.popup("El tag es demasiado extenso")
        else:    
            print("campo de tag correcto.")
            es_correcto = True
            
    else:
        sg.popup("El campo de tag no debe contener espacios vacios o en blanco.")
    
    return es_correcto 

    #--------------------#

def registrar_cambios_config(nick_usuario,operacion_realizada):
    """Funcion recibe nick de usuario cuya sesion esta activa, y el tipo de operacion a registrar.    
        Obtiene fecha y hora actual utilizando modulo datetime.
        Registra evento en archivo log del sistema."""

    #Obtener fecha y hora con formato local.
    timestamp = datetime.timestamp(datetime.now())
    # fecha_hora = datetime.fromtimestamp(timestamp)
    # fecha_hora= fecha_hora.strftime("%d/%m/%Y, %H:%M:%S")

    
    #Registrar en archivo de log.
    #-Ruta de archivo donde guardar datos.
    ruta_log = os.path.join(directorio_base,"src","data","logs_sistema.csv")

    #-Escribir datos.
    with open(ruta_log, "a")as archivo_csv:
        writer = csv.writer(archivo_csv)
        writer.writerow([timestamp, nick_usuario, operacion_realizada]) 

    #--------------------#



def generar_columna_1(dir_repo_imag):
    """Funcion que retorna los componentes de la columna 1 de la fila 2, del layout de la
       ventana. Recibe como parametro la direccion del repositorio de imagen."""

    #Lista de archivos a mostrar en el "ListBox".
    archivos = [(archivo.name, archivo.path) for archivo in os.scandir(dir_repo_imag) if archivo.is_file()]
    
    #Componentes columna 1.
    columna_1 = [
                [
                sg.Column([[sg.Listbox(values=[archivo[0] for archivo in archivos],size=(15, 10),key="-BROWSER-",enable_events=True)],
                [sg.Text("Tag")],
                [sg.Input(key= '-INPUT_TAG-'), sg.Button("Agregar", key='-GUARDAR_TAG-')],  

                [sg.Text("Texto descriptivo")],
                [sg.Input(key= '-INPUT_TEXTO_DESCRIPTIVO-'), sg.Button("Agregar", key='-GUARDAR_TEXTO_DESCRIPTIVO-')],]
                )
                ]


              ]
    
    return columna_1

    #--------------------#
  
    

def generar_columna_2():
    """Funcion que retorna los componentes de la columna 2 de la fila 2, del layout 
       de la ventana"""
    
    columna_2 = [
                [sg.Column([
                    
                [sg.Text("nombre de imagen", key= '-NOMBRE-')],

                [sg.Image(source= None, key= '-IMAGEN-',size=(180,180))], #Acceder a imagen por default en blanco.

                [sg.Text("extension", key= '-EXTENSION-'), sg.Text("peso", key= '-PESO-'), sg.Text("resolucion", key= '-RESOLUCION-')], 
                
                # Creacion de tags y boton de borrar
                [sg.Text("tag", key="-TAG_1-"), 
                 sg.Button("X", key='-BOTON_X_1-', button_color=(None, sg.theme_background_color()), enable_events=True), 
                 
                 sg.Text("tag", key = '-TAG_2-'), 
                 sg.Button("X", key='-BOTON_X_2-', button_color=(None, sg.theme_background_color()), enable_events=True), 
                 
                 sg.Text("tag", key = '-TAG_3-'), 
                 sg.Button("X", key='-BOTON_X_3-', button_color=(None, sg.theme_background_color()), enable_events=True)],  

                [sg.Text("Descripcion:")],   
                [sg.Text(" ", key = '-DESCRIPCION-')]   
                
                ],key= '-COLUMNA2-')]                                     

    ]

    return columna_2   

    #--------------------#



def generar_layout(dir_repo_imag):
    """Funcion que genera layout principal de la ventana"""
 
    titulo = sg.Text("Etiquetar imagenes",
                     size= (15,1),
                     pad=((0,0), (0, 40)), 
                     font = ("Comic Sans MS", 20), 
                     key = "-TITULO_CONFIGURACION-")
    

    volver = sg.Button("Volver", 
                        size= (10,1), 
                        pad=((0,0), (0, 40)),
                        font=("Comic Sans MS", 11),
                        key = "-BOTON_VOLVER-")



    #Layout principal.
    layout = [[titulo, sg.Push(), volver],   #Fila 1.
              [sg.Column(generar_columna_1(dir_repo_imag)), sg.Push(), sg.Column(generar_columna_2())],#Fila 2.   
              [sg.Push(),sg.Button('Guardar',key= '-GUARDAR-')]#Fila3.
              ]
    
    return layout




def ejecutar_etiquetar_imagenes(usuario):
    """Esta funcionalidad permite clasificar las imagenes contenidas en el directorio
        que se configuro como repositorio de imagenes para aplicacion."""
    
    #-Obtener direccion del archivo de config con las rutas de carpetas de imagenes. 
    ruta_archi_config= os.path.join(directorio_base, "common", "config_directorios.json")

    #-Abrir archivo de config y cargar datos en variable.
    with open(ruta_archi_config, "r") as archi_config:
        datos = json.load(archi_config)  

    #-Guardar dato de interes.
    dir_repo_imag = datos["DIRECC_REPO_IMAGENES"]
    
  
    #Crear ventana.
    window = sg.Window("UNLPIMage-Etiquetar Imagenes", 
                       generar_layout(dir_repo_imag), 
                       size= (ancho_window, alto_window),
                       finalize=True,
                       resizable=True)


    #Establecer tamanio minimo de pantalla.
    window.set_min_size((ancho_window, alto_window))


    esta_en_csv = False
    valor_browser = False


#CODIGO PRINCIPAL -------------------------------------------------------------------- 

#Bloque while. #Ultimo en modificarla cuando se guarda.
    while True:
        #Eventos y valores.
        event, values = window.read()
        
        #Acciones segun casos.
        match event:
            case sg.WIN_CLOSED:
                sg.popup("Saliendo de la aplicacion")
                exit()

            case "-BOTON_VOLVER-": 
                break

            case '-BROWSER-':           #Al elegir una imagen del repositorio se actualiza en pantalla.
                imagen = os.path.join(dir_repo_imag,values['-BROWSER-'][0])
                imagen_pil = resize_image(imagen) #MARCA
                imagen_aux = Image.open(imagen)
                
                bio = ImageTk.PhotoImage(imagen_pil)

                nombre_archivo = os.path.split(imagen)[1]
                window['-NOMBRE-'].update(nombre_archivo)
                window['-IMAGEN-'].update( data= bio )
                window['-EXTENSION-'].update("." + str(imagen_aux.format)) #MARCA
                window['-PESO-'].update(str(round(os.path.getsize(imagen)/1024/1024,2)) + "Kb")
                window['-RESOLUCION-'].update(imagen_aux.size)
                
                esta_en_csv,imagen = buscar_imagen(os.path.join(dir_repo_imag,values['-BROWSER-'][0])) #Se busca si esta en el csv para tomar sus valores.
                valor_browser = True

                if esta_en_csv:
                   tags = (imagen["tags"])
                   cant_tag = tags.split('-')
                   if "" in cant_tag:
                    cant_tag.remove("")
                   
                   match len(cant_tag):    #En base a la cantidad de tags que haya, se actualiza por posicion.
                       case 1:
                           window['-TAG_1-'].update(cant_tag[0])
                       case 2:
                           window['-TAG_1-'].update(cant_tag[0])
                           window['-TAG_2-'].update(cant_tag[1])
                        
                       case 3:
                           window['-TAG_1-'].update(cant_tag[0])
                           window['-TAG_2-'].update(cant_tag[1])
                           window['-TAG_3-'].update(cant_tag[2])    
                    
                   
                   window['-DESCRIPCION-'].update(imagen["descripcion"])
               
                else:           #Si no esta en el csv se actualiza por valores default.
                
                    window['-TAG_1-'].update("tag")
                    window['-TAG_2-'].update("tag")
                    window['-TAG_3-'].update("tag") 
                    window['-DESCRIPCION-'].update("")
            
            case '-GUARDAR_TAG-': 
                if valor_browser:    
                    if comprobar_tag(values['-INPUT_TAG-']):
    
                        if esta_en_csv:          
                            tags = imagen["tags"]
                            tags = tags.split(",")
                            if(len(tags) < 3):           #Se pregunta tag por tag si no es default y se actualiza.
                                tags.append(values['-INPUT_TAG-'])
                                if(window['-TAG_1-'].get()== "tag"):
                                    window['-TAG_1-'].update(values['-INPUT_TAG-'])
                                elif(window['-TAG_2-'].get() == "tag"): 
                                    window['-TAG_2-'].update(values['-INPUT_TAG-']) 
                                elif(window['-TAG_3-'].get() == "tag"): 
                                    window['-TAG_3-'].update(values['-INPUT_TAG-'])
                            
                            else:    #Si hay mas de 3 tags no deja guardar.
                                sg.popup("Maxima cantidad de tags ocupada")


                        else:
                            if(window['-TAG_1-'].get() == "tag"):
                                window['-TAG_1-'].update(values['-INPUT_TAG-'])
                                
                            elif(window['-TAG_2-'].get() == "tag"): 
                                window['-TAG_2-'].update(values['-INPUT_TAG-'])
                                
                            elif(window['-TAG_3-'].get() == "tag"): 
                                window['-TAG_3-'].update(values['-INPUT_TAG-']) 
                                
                            else :
                                sg.popup("Maxima cantidad de tags ocupada")           
       

            
            case '-GUARDAR_TEXTO_DESCRIPTIVO-':   #Se actualiza la descripcion con el valor ingresado.
                if valor_browser:
                    if comprobar_descripcion(values['-INPUT_TEXTO_DESCRIPTIVO-']):
                        window['-DESCRIPCION-'].update(values['-INPUT_TEXTO_DESCRIPTIVO-'])
           

            case '-BOTON_X_1-':    #Se borran los tags
                window['-TAG_1-'].update ("tag")
                    
            case '-BOTON_X_2-':
                window['-TAG_2-'].update ("tag")
            case '-BOTON_X_3-': 
                window['-TAG_3-'].update ("tag")   
            
            case '-GUARDAR-':      #Se guarda la imagen con los datos generados en el archivo csv.
                if valor_browser:
                    tags_nuevos=""
                    if(window['-TAG_1-'].get() != "tag"):
                        tags_nuevos= tags_nuevos + window['-TAG_1-'].get() + "-"
                        print(window['-TAG_1-'].get())
                        
                    if(window['-TAG_2-'].get() != "tag"): 
                        tags_nuevos= tags_nuevos + window['-TAG_2-'].get()  + "-"
                        print(window['-TAG_2-'].get())
                        
                    if(window['-TAG_3-'].get() != "tag"): 
                        tags_nuevos= tags_nuevos + window['-TAG_3-'].get() 
                        print(window['-TAG_3-'].get())

                    
                    dir_img_aux_ = values['-BROWSER-'][0]
                    ruta_= os.path.join(dir_repo_imag, dir_img_aux_)
                    dir_img_aux_ = ruta_.replace(os.path.sep, "/")                                        
                    imagen_nueva={"direccion": dir_img_aux_, "extension": window['-EXTENSION-'].get(), "tamanio": window['-PESO-'].get(),
                                  "resolucion": window['-RESOLUCION-'].get(), "tags": tags_nuevos, "descripcion": window['-DESCRIPCION-'].get(),
                                  "modificacion": usuario['nick'], "fecha": fecha_hora}
                    

                    datos = []
                    with open(ruta_csv_imagenes, 'r', encoding=codificacion, newline='') as archivo:
                        lector_csv = csv.DictReader(archivo, delimiter=',')
                        for linea in lector_csv:
                            datos.append(linea)

                    # Buscar el elemento en la lista de diccionarios
                    encontrado = False
                    for linea in datos:
                        if linea['direccion'] == imagen_nueva['direccion']:
                            linea.update(imagen_nueva) # Actualizar los datos de la linea
                            encontrado = True
                            break

                    # Si no se encuentra el elemento, agregarlo como un nuevo diccionario en la lista
                    if not encontrado:
                        datos.append(imagen_nueva)

                    # Escribir la lista actualizada en el archivo CSV
                    with open(ruta_csv_imagenes, 'w', encoding=codificacion, newline='') as archivo:
                        escritor_csv = csv.DictWriter(archivo, fieldnames=datos[0].keys())
                        escritor_csv.writeheader()  # Escribir los encabezados
                        for linea in datos:
                            escritor_csv.writerow(linea)  # Escribir los datos de cada linea
                    if encontrado:
                        operacion = "modificacion de imagen previamente clasificada"
                    else: 
                        operacion = "nueva imagen clasificada"     
                    
                    sg.popup("SE GUARDO CORRECTAMENTE")

                    registrar_cambios_config(usuario['nick'],operacion)                 
                            
                        
    window.close() 
    #------------------------------#
