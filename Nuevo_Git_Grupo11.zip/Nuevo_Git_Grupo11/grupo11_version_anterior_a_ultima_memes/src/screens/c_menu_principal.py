import PySimpleGUI as sg
import os
from PIL import Image, ImageTk
from common.constants import alto_window, ancho_window
from common.constants import directorio_base
from src.screens.d_editar_perfil import ejecutar_editar_perfil
from src.screens import e_configuracion
#from src.screens.f_generador_de_memes import ejecutar_generador_de_memes
from src.screens.g_generador_de_collage import ejecutar_generador_de_collage
from src.screens.h_etiquetar_imagenes import ejecutar_etiquetar_imagenes

#nuevo
from src.screens.f_generador_de_memes_1 import ejecutar_generador_de_memes1



ayuda = """
-En la esquina superior izquierda donde está su avatar y nick usted puede editar su perfil
-En la esquina superior derecha usted puede acceder a la pestaña de configuración tocando el engranaje
-En el centro tiene las opciones para:
    Etiquetar Imagen
    Generar Meme
    Generar Collage
    Salir
"""   

engraje = os.path.join(directorio_base,"src","images","engranaje.png")


def crear_layout_secundario(usuario):
    """Creacion de layout Secundario el cual tiene la foto y nick del usuario, el botón de configuración general y un botón de ayuda"""
    imagen = usuario["direc_avatar"]
    imagen_pil = Image.open(imagen)
    
    layout_secundario = [
            sg.Button(image_source=usuario["direc_avatar"],
            image_subsample= 6 if imagen_pil.size >= (400,400) else 0,
            image_size=(50,50), key= '-EDITAR_PERFIL-',tooltip= usuario["nick"]),
            sg.Text('-'+ usuario["nick"]+'-'),sg.Push(),sg.Button(image_filename= engraje,image_size=(50,50),image_subsample=7, key = "-CONFIGURACION-",size= (10,3),tooltip= 'Configuración'), sg.Button("Ayuda", key = "-AYUDA-",size= (6,2))
            ]
    return layout_secundario

def ejecutar_menu_principal(usuario):
    """ Creo el layout del menú principal, el cual tiene layout principal con los botones para abrir pestañas, se inserta el layout secundario"""
    size_button = (25,3)
    def crear_layout_principal():
        layout_principal = [[sg.Column(
                [
                [sg.Button("Etiquetar Imagen",key = "-ETIQUETAR_IMAGEN-", size= size_button)],
                [sg.Button("Generar Meme", key = "-GENERAR_MEME-",size = size_button)],
                [sg.Button("Generar Collage", key = "-GENERAR_COLLAGE-",size = size_button)],
                [sg.Button("Salir", key = "-SALIR-",size = size_button)]
                ],element_justification="c"
                )
            ]
            ]
        return layout_principal
    layout_secundario = crear_layout_secundario(usuario)
    
    layout_principal = crear_layout_principal()
    layout = [
        layout_secundario,
        [sg.Column(layout_principal )]
    ]
    
    window = sg.Window("UNLPImage-Menu Principal", layout,size=(ancho_window,alto_window), element_justification='center')


    while True:
        event, value = window.read()
        

        if ( event == "-SALIR-"):
            break
        elif (event == sg.WIN_CLOSED):
            sg.popup("Saliendo de la Aplicacion")
            exit()
        elif(event == "-AYUDA-"):
            sg.popup("Sección Ayuda",ayuda)
        else: 
            window.hide()
            if event == "-CONFIGURACION-":
                e_configuracion.ejecutar_configuracion(usuario['nick'])
                window.un_hide()
            elif event == "-EDITAR_PERFIL-":
                usuario_actualizado = ejecutar_editar_perfil(usuario)
                usuario= usuario_actualizado
                window.close()
                layout_secundario = crear_layout_secundario(usuario_actualizado)
                layout_principal = crear_layout_principal()
                layout = [
                    layout_secundario,
                    [sg.Column(layout_principal)]
                ]
                window = sg.Window("Menu Principal", layout,size=(ancho_window,alto_window), element_justification='center')
            elif(event == '-ETIQUETAR_IMAGEN-') :
                ejecutar_etiquetar_imagenes(usuario)
                window.un_hide()

            elif(event == '-GENERAR_MEME-'):  
                #nuevo              
                #ejecutar_generador_de_memes()
                ejecutar_generador_de_memes1()

                window.un_hide()

            elif(event == '-GENERAR_COLLAGE-'):
                ejecutar_generador_de_collage()
                window.un_hide()
            
    window.close()       