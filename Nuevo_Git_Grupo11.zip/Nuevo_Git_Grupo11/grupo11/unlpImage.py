from src.screens import a_inicio

if __name__=="__main__":
	a_inicio.ejecutar_inicio()
