# UNLP Image
## La aplicacion de escritorio para crear memes y collages

UNLP Image es una aplicación que permite crear imágenes a partir de otras combinadas con posibilidad de agregar texto. 

Es decir, esta app nos permitirá:
  - crear un collage con fotos o imágenes disponibles en nuestra computadora
  
  - generar un meme a través de combinación de imágenes con texto y emojis

Ademas, se podrá clasificar las imágenes, y acceder a aquellas que se encuentran almacenadas en nuestra computadora a través de información sobre las mismas.

Asimismo, la app permitira al usuario crear un perfil con sus datos y preferencias.

## Features o Caracteristicas
 - Generador de memes
 - Generador de collage
 - Etiquetar imágenes y almacenarlas con sus datos especificos

En esta app la interfaz gráfica de usuario es amigable y fácil de usar permitiendo la interacción de manera intuitiva.


## Tecnologia utilizada
UNLPImage fue desarrollado utilizando el siguiente software:

- [Python] - Lenguaje de programacion.
- [Visual Studio Code] - Entorno de desarrollo integrado.


## Instalacion
UNLPImage requiere Python v3.11+  para ejecutarse correctamente.
(Ademas de PySimpleGUI, Pillow). Ver "Requirements.txt".


## Desarrollo
Para contribuciones, contactarse a:
alance10a@gmail.com, mateocarusotti@gmail.com, valeds.gelp@gmail.com, figarilucas4@gmail.com 



## Licencia

UNLPImage es open source con repositorio en
https://gitlab.catedras.linti.unlp.edu.ar/.

Licencia Apache, Versión 2.0.
 (Ver "License.md")

**Software libre!**


## Autores
- Carreras, Alan.
- Carusotti, Mateo.
- Di Santo, Valentin.
- Figari, Lucas.





