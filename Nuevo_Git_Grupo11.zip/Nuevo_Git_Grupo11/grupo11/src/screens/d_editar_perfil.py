import PySimpleGUI as sg
import os
from PIL import Image, ImageTk
import json

from common.constants import directorio_base
from common.constants import dir_avatar_default
from common.constants import dir_collages
from common.constants import dir_memes
from common.constants import ANCH_WINDOW, ALTO_WINDOW 
from common.constants import H1_SIZE

#nuevo.
from config.paths import convertir_para_guardar





extensiones = [ ("Archivos png", ".png")] #extensiones para imagenes


#==============================================================================
#-------------- Funciones

def resize_image(path_de_imagen_obtenida):
    '''En esta función se escalan las imagenes cargadas desde el sg.Filebrowse al tamaño correspondiente
    para que se vean lo relativamente correctas en la pantalla.
    Para ésto se toman diferentes tamaños en consideración:
    Si la imagen tiene un tamaño mayor a 150 pixels o menor a 100 pixeles en cualquiera de sus lados,
    ésta se escalará a dichotamaño lo mejor posible.
    Manteniendo la relación de aspecto original de la imagen (relación entre la medida del lado más 
    largo y la del lado más corto.)
    '''

    with Image.open(path_de_imagen_obtenida) as imagen:
        # obtener las dimensiones de la imagen original
        ANCHO_WINDOW, alto = imagen.size

        # calcular el nuevo tamaño de la imagen
        max_ANCHO_WINDOW = 150
        max_alto = 150
        if ANCHO_WINDOW < 100 or alto < 100:
            max_ANCHO_WINDOW = 150
            max_alto = 150
        elif ANCHO_WINDOW > 150 or alto > 150:
            relacion_de_aspecto = ANCHO_WINDOW / alto
            if relacion_de_aspecto > 1:
                ANCHO_WINDOW = max_ANCHO_WINDOW
                alto = int(ANCHO_WINDOW / relacion_de_aspecto)
            else:
                alto = max_alto
                ANCHO_WINDOW = int(alto * relacion_de_aspecto)

        # redimensionar la imagen si es necesario
        if ANCHO_WINDOW != imagen.width or alto != imagen.height:
            imagen_redimensionada = imagen.resize((ANCHO_WINDOW, alto))
        else:
            imagen_redimensionada = imagen.copy()

        return imagen_redimensionada





def comprobar_campos_completos(ni, nom, g, c, e):
    "funcion que comprueba que ningun campo se encuentre vacío. Recibe como parametros el nick, nombre, genero, correo y edad en ese orden."
    print("comienza el comprobar campos completos")
    aux_campos = (ni, nom, g, c,)
    for i in aux_campos:
        if not(i == '' or i == ' ') and not(i.startswith(' ')):
          aux = True
        else:
            sg.popup("Completar correctamente cada campo.")
            print("Falta un campo")
            aux = False
            break
    if aux:
        try:
            if not (int(e) in range(18,101)):
                aux = False
                sg.popup("La edad debe ser entre 18 y 100 años.")
        except:
            aux = False
            sg.popup("La edad debe ser un número entero")

    return aux

    
        
        



def comprobar_formato_correo(correo):
    "funcion que comprueba si el formato del correo electronico ingresado es correcto. Recibe como parametros el correo"
    print("comenzar comprobar formato correo")
    
    if '@' in correo:
        if correo.endswith(".com") or correo.endswith(".es") or correo.endswith(".ar"):
          return True
        else:
            print("no termina en .com, .ar, .es")
            sg.popup("El correo electronico debe terminar en .com/.ar/.es")
    else:
        print("falta el @")
        sg.popup("el correo electronico no es valido(no contiene @)")
    
    return False

def nick_es_unico(nick_usuario, nick):
    "funcion que recorre el archivo de usuarios registrados para asegurarse de que el nick ingresado no este repetido"
    print("comprobando nick unico")
    
    x = True   #boolean que determina si se encuentra el nick repetido o es unico--------
    pos = 0
    ruta_archivo = os.path.join(directorio_base,"src","data","usuarios.json")  
    try:
        with open(ruta_archivo, 'r') as rut:
            datos = json.load(rut)
            print(f"DATOS LISTA:{datos}")                                             
            while x and (pos < len(datos)):     #se trabaja con el archivo-----     
                if datos[pos]['nick'] == nick_usuario:
                    if datos[pos]['nick'] != nick:
                        x = False
                        sg.popup("El nick ingresado ya existe. Por favor ingrese otro.")
                        break
                    else:
                        break
                else:
                    pos += 1
    except json.decoder.JSONDecodeError:#---manejo de excepcion en caso de que falle la carga del archivo (puede suceder si esta vacio)-------
        print("error json.decode.jsondecodeerror ya que el archivo no se pudo cargar correctamente (si es el primer usuario que se crea puede saltar este error ya que no tiene nada cargado de antes el archivo.json)")
        print("Archivo vacio, no hay ningun usuario para comparar")
    
    return x


def guardar_datos(usuario, nick_usuario, nombre_usuario, genero_usuario, correo_usuario, edad_usuario, avatar_seleccionado):
    "funcion que estructura los datos del formulario como un diccionario para el formato json, e invoca otro metodo por el cual envía la estructura de datos para ser guardada en un archivo json"
    print("comenzar funcion guardar_datos")
                  
    #nuevo.
    avatar_seleccionado = convertir_para_guardar(avatar_seleccionado, directorio_base)

    dicc_datos= {}
    if comprobar_campos_completos(nick_usuario, nombre_usuario, genero_usuario, correo_usuario, edad_usuario):   #---ANALIZA QUE LOS DATOS SEAN VALIDOS---
        if comprobar_formato_correo(correo_usuario):
                if nick_es_unico(nick_usuario, usuario['nick']):
                    dicc_datos = {"nick":nick_usuario,                       #DICCIONARIO CON VALORES INGRESADOS
                            "nombre":nombre_usuario,
                            "genero":genero_usuario,
                            "correo":correo_usuario,
                            "edad":edad_usuario,
                            "direc_avatar":avatar_seleccionado
                            }
                    ruta_archivo = os.path.join(directorio_base,"src","data","usuarios.json")
                    try:
                        with open(ruta_archivo,'r') as archivo_usuarios:
                            archivo = json.load(archivo_usuarios)
                        
                        for x, y in enumerate(archivo):
                            if (str(y["nick"]) == str(usuario["nick"])):
                                # Sobrescribir los datos del usuario
                                archivo[x] = dicc_datos
                                break
                            
  
                        
                        
                        with open(ruta_archivo,'w') as archivo_usuarios:
                            json.dump(archivo, archivo_usuarios, indent=4)          #CARGA LOS VALORES EN EL ARCHIVO USUARIOS.JSON
                            sg.popup("Usuario guardado correctamente :D")
                            return True, dicc_datos
                    except Exception:
                        print("No se pudo guardar el usuario")
                        return False, dicc_datos
    return False, dicc_datos


#==============================================================================
#-------------- Programa



def ejecutar_editar_perfil(usuario):
    button_size1= ((int(ANCH_WINDOW / 50)), (int(ALTO_WINDOW / 160)))
    button_size2= ((int(ANCH_WINDOW / 50)), (int(ALTO_WINDOW / 250)))
    text_size1= int(ANCH_WINDOW / 45)

    input_size1= ((int(ANCH_WINDOW / 15)), (int(ALTO_WINDOW / 250)))


    pad_text1= ((int(ANCH_WINDOW / 100)), ((int(ALTO_WINDOW / 10)), 0))
    pad_text2= ((int(ANCH_WINDOW / 100)), ((int(ALTO_WINDOW / 30)), 0))

    change_file_path= usuario["direc_avatar"]
    generos = ('Masculino','Femenino','Otro')

    layout= [
        
        [
        sg.Column([
            [sg.Image(source=usuario['direc_avatar'] , key='-IMG-', pad=((int(ANCH_WINDOW / 15)), (int(ALTO_WINDOW / 30), 0)), size=(150,150), expand_x=True )],
            [sg.FileBrowse('Cargar Imagen', key='-CARGAR_IMG-', size=(button_size1), pad=((int(ANCH_WINDOW / 10)), (int(ALTO_WINDOW / 96))), enable_events=True, file_types= extensiones)],
            [sg.Button("Guardar", key='-GUARDAR_CAMBIOS-', pad=((5,0),((int(ANCH_WINDOW/4)),0)), size=(button_size2))],
            [sg.Button("Cancelar", key='-CANCELAR-', size=(button_size2), )]
        ], expand_y=True, vertical_alignment="top", key='-COLUMNA_IZQUIERDA-'),
        
        sg.Column([
            [sg.Text("Nick o Alias",pad=pad_text1,  )],
            [sg.InputText(key='-NICK-', size=input_size1, default_text=usuario['nick'])],
            [sg.Text("Nombre", pad=pad_text2, )],
            [sg.InputText(key='-NOMBRE-', size=input_size1, default_text=usuario['nombre'])],
            [sg.Text("Correo", pad=pad_text2, font=('Franklin Gothic Demi Cond', text_size1))],
            [sg.InputText(key='-CORREO_ELECTRONICO-', size=input_size1, default_text=usuario['correo'])],
            [sg.Text("Edad", pad=pad_text2, )],
            [sg.InputText(key='-EDAD-', size=input_size1, default_text=usuario['edad'])],
            [sg.Text("Género", pad=pad_text2, )],
            [sg.Combo(generos, key= '-GENERO-',  readonly=True, expand_x=True, enable_events=True, size=input_size1, default_value=usuario['genero'])],

            
        ], expand_y=True, vertical_alignment="top", key='-COLUMNA_DERECHA-'), 
    ]
    ]

    window = sg.Window('UNLPImage-Editar Perfil', layout, size=(ANCH_WINDOW, ALTO_WINDOW), finalize=True)
    window.set_min_size((680, 460))

   

    guardado  = False
    while True:
        event, values = window.read()

        if (event == sg.WIN_CLOSED):
            sg.popup("Saliendo de la aplicacion")
            exit()
        
        if (event == '-CANCELAR-'):
            #se controla que ninguno de los valores en los campos sea distinto a los establecidos
            #por default. Si ésto se cumple entonces se retornan los datos del usuario tal cual 
            #se ingresaron. En caso contrario, se pregunta se consulta al usuario antes de volver
            #al menu.
            if (values['-NICK-'] != usuario['nick']) or (values['-NOMBRE-'] != usuario['nombre']) or (values['-CORREO_ELECTRONICO-'] != usuario['correo']) or (values['-EDAD-'] != usuario['edad']) or (values['-GENERO-'] != usuario['genero']) or (values['-CARGAR_IMG-'] != usuario['direc_avatar']) :
                salir = sg.PopupYesNo("¿Estás seguro que deseas salir sin guardar los cambios?")
                if salir == 'Yes':
                    window.hide()
                    return usuario
            else:
                window.hide()
                return usuario


        if (event == '-CARGAR_IMG-'):
            #Se carga la imagen y si no devuelve Nono (si el usuario no clickea el botón de cancelar)
            #entonces se carga la nueva imagen.

            imagen= values['-CARGAR_IMG-']

            if imagen is not None:
                change_file_path = values['-CARGAR_IMG-']
                imagen= resize_image(change_file_path)
                
                imagen = ImageTk.PhotoImage(imagen)
                
                window['-IMG-'].update(data = imagen, subsample=2)  
                
        
        
        if (event == '-GUARDAR_CAMBIOS-'):

            nick_usuario = values['-NICK-']
            nombre_usuario = values['-NOMBRE-']
            correo_usuario = values['-CORREO_ELECTRONICO-']
            edad_usuario = values['-EDAD-']
            genero_usuario = values['-GENERO-']

            guardado, usuario_guardado = guardar_datos(usuario, nick_usuario, nombre_usuario, genero_usuario, correo_usuario, edad_usuario, change_file_path)
            if guardado:
                window.hide()
                return usuario_guardado
                
            

            
            


            

 
    




