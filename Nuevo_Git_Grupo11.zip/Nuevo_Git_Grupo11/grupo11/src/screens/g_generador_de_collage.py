#UNLPImage
#Generador de collage

#Importar modulos y constantes.
import PySimpleGUI as sg
import os
import json
from common.constants import ANCH_WINDOW, ALTO_WINDOW
from common.constants import directorio_base


#Ruta de archivo de donde se obtiene direccion del repositorio de imagenes. 
ruta_archi_config_directorios_imagenes= os.path.join(directorio_base, "common", "config_directorios.json")



def generar_layout(dir_repo_imag):
    """Funcion que recibe direccion del repositorior de imagenes (para usarlo como carpeta default) 
       y devuelve componentes de la ventana a ejecutar.    
    """

    #Ventana.
    #-Componentes.    
    #Fila1.    
    volver = sg.Button("Volver", 
                       size= (10,1), 
                       pad=((0,0), (0, 20)),                       
                       key = "-BOTON_VOLVER-")    

    
    #Fila2.
    #recuadro_imagen = [sg.Image(source=" " ,key="-RECUADRO_IMAGEN-")]
    recuadro_imagen = [sg.Image(background_color="white", size= (100, 100), expand_x=True, expand_y=True ,key="-RECUADRO_IMAGEN-")]


    #Fila3.
    #-Columna.
    opciones_cant_imag = ['1', '2', '3']
    opciones_tipo_plantilla = ['A', 'B', 'C']

    columna = [
                [sg.Combo(opciones_cant_imag, default_value= '-Cantidad de imagenes-', size=(17,1), readonly= True, pad=((4,0),(10,5)), key= '-COMBO_CANT_IMAGENES-'),
                 sg.Combo(opciones_tipo_plantilla, default_value= '-Tipo de plantilla-', size=(14,1), readonly= True, pad=((10,0),(10,5)), key= '-COMBO_TIPO_PLANTILLA-')
                ],
                
                [sg.Input(key= "-INPUT_IMAGEN_1-"),
                 sg.FileBrowse("Seleccionar", initial_folder=dir_repo_imag)],
                
                [sg.Input(key= "-INPUT_IMAGEN_2-"),
                 sg.FileBrowse("Seleccionar", initial_folder=dir_repo_imag)],

                [sg.Input(key= "-INPUT_IMAGEN_3-"),
                 sg.FileBrowse("Seleccionar", initial_folder=dir_repo_imag)],

                [sg.Button("Actualizar",                              
                            key= "-BOTON_ACTUALIZAR-",
                            pad=((5,0), (31, 0))),
                 sg.Button("Guardar",                             
                            pad=((170,0), (30, 0)), 
                            key= "-BOTON_GUARDAR-")] 

              ]  
    
    
    #------------------------------#



    #layout a retornar.
    layout = [              
              [sg.Push(), volver], 
              
              [recuadro_imagen],

              [sg.Column(layout= columna, 
                         justification="center",                         
                         key="-COLUMNA_PRINCIPAL-",                                                                                                 
                         ),                         
               ],                                                  
             ]   


    return layout

    #------------------------------#



#-Ejecucion.
def ejecutar_generador_de_collage():
    """Funcion que crea la ventana de generador de collage; la ejecuta, procesa los eventos y la cierra.
       (Para esta primera parte de la entrega, solo tienen funcionalidad los botones 'x', "volver" y los FolderBrowse). 
    """

    #-Abrir archivo de config y cargar sus datos en variable.
    with open(ruta_archi_config_directorios_imagenes, "r") as archi_config_imag:
        datos = json.load(archi_config_imag)  

    #-Guardar direccion de repositorio de imagenes.
    dir_repo_imag = datos["DIRECC_REPO_IMAGENES"]
    
    
    #-Crear ventana.     
    window = sg.Window("UNLPImage-Generar collage", 
                       generar_layout(dir_repo_imag), 
                       size= (ANCH_WINDOW, ALTO_WINDOW),
                       finalize=True,
                       resizable=True)

    #-Establecer tamanio minimo de pantalla.
    window.set_min_size((ANCH_WINDOW, ALTO_WINDOW))


    #-Bloque while.
    while True:
        #Eventos y valores.
        event, values = window.read()                      
                
        #Acciones segun casos.
        match event:
            case sg.WIN_CLOSED:
                sg.popup("Saliendo de la aplicacion")
                exit()
            
            case "-BOTON_VOLVER-": 
                break
                         

    #-Cerrar ventana.
    window.close()

    #------------------------------#