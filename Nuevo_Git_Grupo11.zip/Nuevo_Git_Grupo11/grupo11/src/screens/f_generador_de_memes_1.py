#UNLPImage
#Pantalla 1 de generador_de_memes

#Importar modulos y constantes.
import os
import json
import PySimpleGUI as sg
from PIL import Image, ImageTk
from common.constants import ANCH_WINDOW, ALTO_WINDOW, directorio_base, H1_SIZE, TEXT_SIZE
from src.screens.f_generador_de_memes_2 import ejecutar_generador_de_memes_2



#Ruta de archivo de donde se obtiene direccion del repositorio de imagenes. 
ruta_archi_config_directorios_imagenes= os.path.join(directorio_base, "common", "config_directorios.json")


#Revisar.
#Tienen que quedar todas la imagenes con resolucion 400x400 o cercana.
def resize_image(path_de_imagen_obtenida):
    """En esta función se escalan las imagenes cargadas desde el sg.Filebrowse al tamaño correspondiente
    para que se vean lo relativamente correctas en la pantalla.

    Para ésto se toman diferentes tamaños en consideración:
      Si la imagen tiene un tamaño mayor a 150 pixels o menor a 100 pixeles en cualquiera de sus lados,
      ésta se escalará a dicho tamaño lo mejor posible.

      Manteniendo la relación de aspecto original de la imagen (relación entre la medida del lado más 
      largo y la del lado más corto.)"""
    
    """_summary_

    Returns:
        _type_: _description_
    """


    with Image.open(path_de_imagen_obtenida) as imagen:
        # obtener las dimensiones de la imagen original
        ANCHO_WINDOW, alto = imagen.size

        # calcular el nuevo tamaño de la imagen                
        max_ANCHO_WINDOW = 400        
        max_alto = 400

        if ANCHO_WINDOW > 400 or alto > 400:
            relacion_de_aspecto = ANCHO_WINDOW / alto

            if relacion_de_aspecto > 1:
                ANCHO_WINDOW = max_ANCHO_WINDOW
                alto = int(ANCHO_WINDOW / relacion_de_aspecto)
                print(f'{alto=}')
            
            else:
                alto = max_alto
                ANCHO_WINDOW = int(alto * relacion_de_aspecto)
                print(f'{ANCHO_WINDOW=}')

        imagen_redimensionada = imagen.resize((ANCHO_WINDOW, alto))

        # redimensionar la imagen si es necesario
        #if ANCHO_WINDOW != imagen.width or alto != imagen.height:
        #    imagen_redimensionada = imagen.resize((ANCHO_WINDOW, alto))

        #else:
        #    imagen_redimensionada = imagen.copy()


        return imagen_redimensionada
    
    #--------------------#



def generar_layout(dir_memes):    
    """_summary_

    Args:
        dir_memes (_type_): _description_

    Returns:
        _type_: _description_
    """

    #Ventana.
    #-Componentes.    
    #Fila1.
    titulo = sg.Text("Generar meme",
                     size= (15,1),
                     pad=((0,0), (0, 40)), 
                     font = ("Comic Sans MS", H1_SIZE), 
                     key = "-TITULO_GENERAR_MEME-")
        
    volver = sg.Button("Volver", 
                       size= (10,1), 
                       pad=((0,0), (5, 40)),                       
                       font=("Comic Sans MS", TEXT_SIZE),
                       key = "-BOTON_VOLVER-")    
        
    #--------------------#

    
    #Fila2.
    subtitulo1 = sg.Text("Seleccionar template",                     
                     pad=((0,0), (0, 40)), 
                     font = ("Comic Sans MS", 15), 
                     key = "-SUBTITULO1_SELECCIONAR_TEMPLATE-")
    
    subtitulo2 = sg.Text("Previsualizacion",                     
                     pad=((0,0), (0, 40)), 
                     font = ("Comic Sans MS", 15), 
                     key = "-SUBTITULO2_PREVISUALIZACION-")
    
    #--------------------#


    #Fila3.   
    #Lista de archivos a mostrar en el "ListBox".
    archivos = [(archivo.name, archivo.path) for archivo in os.scandir(dir_memes) if archivo.is_file()]
    
    #Componentes columna 1.    
    columna_1 = sg.Column([[sg.Listbox(values=[archivo[0] for archivo in archivos],
                           size=(15, 10),
                           key="-BROWSER-",
                           enable_events=True)]])
    
    columna_2 = sg.Column([
                           [sg.Image(source= None, key= '-IMAGEN-',size=(180,180))], #Acceder a imagen por default en blanco.
                           ],
                           key= '-PREVISUALIZACION-IMAGEN-')                                    
    
    #--------------------#


    #Fila 3.
    generar =  sg.Button("Generar",
                         #pad=((170,0), (30, 0)), 
                         pad=((0,0), (30, 0)), 
                         key= "-BOTON_GENERAR-")    
    
    #--------------------#


    #layout a retornar.
    layout = [              
              [titulo, sg.Push(), volver], 

              [subtitulo1, sg.Push(), subtitulo2], 

              [columna_1, sg.Push(), columna_2],

              [sg.Push(), generar]

             ]


    return layout

    #------------------------------#



#-Ejecucion.
def ejecutar_generador_de_memes1():
    """_summary_
    """

    #-Obtener direccion del archivo de config con las rutas de carpetas de imagenes. 
    ruta_archi_config= os.path.join(directorio_base, "common", "config_directorios.json")

    #-Abrir archivo de config y cargar sus datos en variable.
    with open(ruta_archi_config_directorios_imagenes, "r") as archi_config_imag:
        datos = json.load(archi_config_imag)  

    #-Guardar direccion de directorio de memes.
    dir_memes = datos["DIRECC_DIRECTORIO_MEMES"]
    
    
    #-Crear ventana.     
    window = sg.Window("UNLPImage-Generador de memes", 
                       generar_layout(dir_memes), 
                       size= (ANCH_WINDOW, ALTO_WINDOW),
                       finalize=True,
                       resizable=True)

    #-Establecer tamanio minimo de pantalla.
    window.set_min_size((ANCH_WINDOW, ALTO_WINDOW))


    #-Bloque while.
    while True:
        #Eventos y valores.
        event, values = window.read()                      
                
        #Acciones segun casos.
        match event:
            case sg.WIN_CLOSED:
                sg.popup("Saliendo de la aplicacion")
                exit()
            
            case "-BOTON_VOLVER-": 
                break

            case '-BROWSER-':           #Al elegir una imagen del repositorio se actualiza en pantalla.
                imagen = os.path.join(dir_memes, values['-BROWSER-'][0])
                imagen_pil = resize_image(imagen) #MARCA
                imagen_aux = Image.open(imagen)
                
                bio = ImageTk.PhotoImage(imagen_pil)
                                
                window['-IMAGEN-'].update( data= bio )

            case '-BOTON_GENERAR-':
                window.hide()
                ejecutar_generador_de_memes_2(imagen)
                window.un_hide()
                #sg.Popup("Pagina2 de generar_memes en construccion.")
                
                         

    #-Cerrar ventana.
    window.close()

    #------------------------------#


