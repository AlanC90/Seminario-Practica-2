import PySimpleGUI as sg
import sys
import os
import csv
import json
from PIL import Image
from PIL import ImageTk
from PIL import ImageOps
from PIL import ImageDraw
from common.constants import ANCH_WINDOW, ALTO_WINDOW
from common.constants import directorio_base
from common.modulos import lectura_json
from common.modulos import log_sistema

codificacion = sys.getdefaultencoding()
ruta_csv_imagenes = os.path.join(directorio_base, 'src', 'data', 'datos_imagenes.csv')


#-----------------FUNCIONES DEL PROGRAMA---------------------------------------------------------

def tomar_nombre_imagenes (values,cantidad_imagen):
    lista = []
    for indice in range(1,cantidad_imagen + 1):
        if values[f'-BROWSER_{indice}-']:
            nombre = os.path.basename(values[f'-BROWSER_{indice}-'])
            lista.append(nombre)    
    return list(set(lista))
        
def guardar_collage(imagen_a_guardar, titulo):
    """FUNCION QUE GUARDA EL COLLAGE EN LA DIRECCION ESPECIFICADA EN LA SECCION DE CONFIGURACION. SE PASA COMO PARAMETRO LA IMAGEN A GUARDAR. SE ACCEDE AL ARCHIVO DE DIRECTORIOS PARA OBTENER LA RUTA EN DONDE GUARDAR LA IMAGEN. DEVUELVE UN BOOLEANO"""
   
    ruta_archivo = os.path.join(directorio_base,"common","config_directorios.json")
    guardado = False
    
    x = sg.PopupYesNo("¿Desea guardar el collage?", title= "Guardar Collage")
    if x == 'Yes':

#En caso de que el titulo no esté vacío, procede a guardar el collage usando la ruta collage guardada en configuracion.
        if titulo != '':                  
            if (len(titulo) < 20):
                rutas = lectura_json(ruta_archivo)
                ruta_completa_collage = os.path.join(rutas["DIRECC_DIRECTORIO_COLLAGES"], titulo) + ".jpg"
                imagen_a_guardar.save(ruta_completa_collage)
                sg.popup("El collage ha sido guardado exitosamente. Regresando al menú principal...")
                guardado = True
            else:
                sg.popup("Por favor ingrese un título con menos caracteres.")    

        else:
            sg.popup("Por favor ingrese un título válido.")
            
    return guardado



def modificar_browser(imagen_del_browser, collage, datos_collage, window, id_browser):
    """FUNCION MODIFICAR_BROWSER, LA CUAL RECIBE COMO PARAMETRO LA RUTA DEL BROWSER, EL COLLAGE, LOS TIPOS DE COLLAGE, LA VENTANA WINDOW, Y EL IDENTIFICADOR DEL BROWSER"""                         

    tamanio = 'tamanio_' + id_browser
    posicion = 'posicion_' + id_browser

    # Modificar el collage en la posición correspondiente al browser
    imagen = Image.open(imagen_del_browser)
    imagen_pegar = ImageOps.fit(imagen, (datos_collage[tamanio][0], datos_collage[tamanio][1]))
    collage.paste(imagen_pegar, (datos_collage[posicion][0],datos_collage[posicion][1]))
    window['-COLLAGE-'].Update(data= ImageTk.PhotoImage(collage))

    



def buscar_imagen(direc_imagen):
    """Funcion que busca si la imagen se encuentra en el archivo csv, y retorna 
       la imagen. Recibe como parametro la direccion de la imagen."""
    
    esta = False
    
    with open(ruta_csv_imagenes, "r", encoding=codificacion) as archi_imagen:

        direc_imagen = os.path.basename(direc_imagen)
        datos = csv.DictReader(archi_imagen)
        for imagen in datos:
            imagen = imagen['direccion'].split(os.sep)
            if imagen[-1]  == direc_imagen:
                esta = True
                break
    
    return esta

def devolver_botones(botones_seleccionar, cantidad_imagenes):
    
    for indice in range(1,cantidad_imagenes + 1):
        botones_seleccionar.append(sg.FileBrowse(f'Seleccionar Imagen', key= f'-BROWSER_{indice}-', enable_events= True))

def crear_columna_uno(cantidad_imagenes):
    botones_seleccionar = []
    devolver_botones(botones_seleccionar, cantidad_imagenes)
    
    columna_1 = sg.Column(
        [
            botones_seleccionar,
            [sg.Text('Título:')],
            [sg.Input(key='-INPUT_TITULO-')],
            [sg.Button('Aceptar',key='-ACEPTAR_INPUT-')]
        ],justification= 'c'
    )
    
    
    return columna_1

def crear_columna_dos():
    columna_2 = sg.Column(
        [
            [sg.Image( size=(400, 400), key='-COLLAGE-')]
        ]
    )
    
    return columna_2

def ejecutar_generador_collage_2(usuario,datos_collage):
    layout_superior = [
        [sg.Text('Generar collage '), sg.Push(), sg.Button('Volver', key='-VOLVER-')]
    ]
    layout_medio = [
        crear_columna_uno(datos_collage["cantidad"]), sg.Push(), crear_columna_dos()
    ]
    layout_inferior = [
        [sg.Push(), sg.Button('Guardar', key='-GUARDAR-')]
    ]

    layout = [
        layout_superior,
        layout_medio,
        layout_inferior
    ]

#-----------------VARIABLES IMPORTANTES---------------------------------------------------------

    window = sg.Window('UNLPImage-Generador de Collage', layout,finalize=True,resizable=True)
    window.set_min_size((ANCH_WINDOW,ALTO_WINDOW))
    collage = Image.new("RGB", (400, 400))
    copia = collage.copy()
    window["-COLLAGE-"].update(data=ImageTk.PhotoImage(collage))
    titulo_actual = ""

#-----------------INICIO DEL BUCLE PRINCIPAL---------------------------------------------------------

    while True:

        event, values = window.read()
        match event:    
            case sg.WINDOW_CLOSED:
                exit()


            case '-VOLVER-':           
                break


            case '-GUARDAR-':              #BOTON DE GUARDAR EL CUAL ALMACENA LOS DATOS DEL COLLAGE.
                guardado = guardar_collage(copia, titulo_actual)
                if guardado:
                  
                  log_sistema(usuario['nick'],'Generacion de collage',tomar_nombre_imagenes(values,datos_collage["cantidad"]),titulo_actual)
                  break
            

            case '-BROWSER_1-':        #PRIMER BROWSER 
                imagen_seleccionada = values['-BROWSER_1-']
                thumb = buscar_imagen(imagen_seleccionada)
        
                if esta:
                    
                    modificar_browser(imagen_seleccionada, collage, datos_collage, window, '1')

                else:
                
                    sg.popup('Solo se puede usar imágenes etiquetadas')


                
            case '-BROWSER_2-':       #SEGUNDO BROWSER 
                imagen_seleccionada = values['-BROWSER_2-']
                esta = buscar_imagen(imagen_seleccionada)           
                if esta:

                    modificar_browser(imagen_seleccionada, collage, datos_collage, window, '2')

                else:

                    sg.popup('Solo se puede usar imágenes etiquetadas')


            case '-BROWSER_3-':    
                imagen_seleccionada = values['-BROWSER_3-']                #TERCER BROWSER 
                esta = buscar_imagen(imagen_seleccionada)          
                if esta:

                    modificar_browser(imagen_seleccionada, collage, datos_collage, window, '3')

                else:

                    sg.popup('Solo se puede usar imágenes etiquetadas')

            case '-BROWSER_4-':    
                imagen_seleccionada = values['-BROWSER_4-']                #TERCER BROWSER 
                esta = buscar_imagen(imagen_seleccionada)          
                if esta:

                    modificar_browser(imagen_seleccionada, collage, datos_collage, window, '4')

                else:

                    sg.popup('Solo se puede usar imágenes etiquetadas')  


            case '-ACEPTAR_INPUT-':                  #BOTON DE ACEPTAR TITULO 
                copia = collage.copy()
                titulo_actual = values['-INPUT_TITULO-']
                draw = ImageDraw.Draw(copia)   
                draw.text((10,380),values['-INPUT_TITULO-'])
                window['-COLLAGE-'].update(data = ImageTk.PhotoImage(copia))      


    window.close()