import PySimpleGUI as sg
import os
from PIL import Image, ImageTk


from common.constants import ALTO_WINDOW, ANCH_WINDOW, directorio_base



dir_general_de_imag = os.path.join(directorio_base, "src", "images")
extensiones = [ ("Archivos png", ".png")] #extensiones para imagenes
#==============================================================================
#-------------- Modulos

def resize_de_imagen(path_de_imagen_obtenida):

    '''En esta función se escalan las imagenes cargadas desde el sg.Filebrowse al tamaño correspondiente
    para que se vean lo relativamente correctas en la pantalla.
    Para ésto se toman diferentes tamaños en consideración:
        Si la imagen tiene un tamaño mayor a 2000 pixels en cualquiera de sus lados, se escalará a 650x500
        como máximo.
        Si tiene entre 1000 y 2000 pixeles se escalará a 500x333.
        Y si tiene entre 500 y 1000 pixeles se escalará a 500x367.'''

    with Image.open(path_de_imagen_obtenida) as imagen:
        # obtener las dimensiones de la imagen original
        ANCHO_WINDOW, alto = imagen.size

        # calcular el nuevo tamaño de la imagen
        max_ANCHO_WINDOW = 600
        max_alto = 400
        if ANCHO_WINDOW > 4000 or alto > 4000:
            max_ANCHO_WINDOW = 5050
            max_alto = 300
        elif ANCHO_WINDOW > 2000 or alto > 2000:
            max_ANCHO_WINDOW = 650
            max_alto = 500
        elif ANCHO_WINDOW > 1000 or alto > 1000:
            max_ANCHO_WINDOW = 500
            max_alto = 333
        elif ANCHO_WINDOW > 500 or alto > 500:
            max_ANCHO_WINDOW = 500
            max_alto = 367
        

        # redimensionar la imagen si es necesario
        if ANCHO_WINDOW > max_ANCHO_WINDOW or alto > max_alto:

            # calcular la relación de aspecto
            '''La relación de aspecto es la relación entre la medida del lado más largo y la del lado más corto.
            Por ejemplo, si una imagen tiene una resolución de 800x600 píxeles, su relación de aspecto es de 4:3. 
            Esto significa que el ANCHO_WINDOW es 4 veces mayor que el alto. En cambio, si la resolución 
            de una imagen es de 1200x800 píxeles, su relación de aspecto es de 3:2, lo que significa que el 
            ANCHO_WINDOW es 1.5 veces mayor que el alto.'''

            relacion_de_aspecto = ANCHO_WINDOW / alto
            
            

            # calcular las nuevas dimensiones
            if ANCHO_WINDOW > max_ANCHO_WINDOW:
                ANCHO_WINDOW = max_ANCHO_WINDOW
                alto = int(ANCHO_WINDOW / relacion_de_aspecto)
            if alto > max_alto:
                alto = max_alto
                ANCHO_WINDOW = int(alto * relacion_de_aspecto)

            # redimensionar la imagen
            imagen_redimensionada = imagen.resize((ANCHO_WINDOW, alto))
        else:
            imagen_redimensionada = imagen.copy()

        return imagen_redimensionada

#==============================================================================
#-------------- Programa



def ejecutar_generador_de_memes():
    layout = [
        
        [sg.Image(source=None, key='-IMG-', expand_x=True, expand_y=True, size=(300, 300), background_color='black', pad=((0,0),(0,40)))],
        [sg.FileBrowse('Cargar Imagen', key='-CARGAR_IMG-', size=(0, 1), font=('Franklin Gothic Demi Cond', 30), enable_events=True, initial_folder=dir_general_de_imag, file_types= extensiones)],
        [
            sg.Column([
                [sg.InputText('Texto Superior (TOP)', font=('Franklin Gothic Book', 14), pad=((5,0),(10,10)))], 
                [sg.InputText("Texto Inferior (BOTTOM)", font=('Franklin Gothic Book', 14), pad=((5,0),(10,10)))]
            ], justification="right", background_color=None),
            
            sg.Column([
                [sg.Button('Actualizar', key='-ACTUALIZAR-', font=('Franklin Gothic Book', 10), expand_y=True, border_width=3, mouseover_colors="#6699cc")]
            ], expand_x=True, background_color=None),

            sg.Column([
                [sg.Button('<--Volver', key='-VOLVER-', font=('Franklin Gothic Demi Cond', 14))]
            ])

        ]
    ]


    window = sg.Window('UNLPImage-Generar Meme', layout, border_depth=20, finalize=True, size=(ANCH_WINDOW, ALTO_WINDOW), resizable=True)
    
      


    while True:
        event, values = window.read()
        
        if (event == sg.WIN_CLOSED):
            sg.popup("Saliendo de la aplicacion")
            exit()

        if (event == '-VOLVER-'):
            break

        if (event == '-CARGAR_IMG-'):
            #Se guarda el pad de la nueva imagen y en caso de no devolver None (si el usuario no 
            #clickea el botón de cancelar) entonces se carga dicha nueva imagen.

            imagen= values['-CARGAR_IMG-']
            if imagen is not None:
                imagen= resize_de_imagen(imagen)
                window['-IMG-'].update(data = ImageTk.PhotoImage(imagen), subsample=2)  
        
        

    window.close()


