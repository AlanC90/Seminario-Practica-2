import PySimpleGUI as sg
import os
from common.constants import ALTO_WINDOW, ANCH_WINDOW
from common.constants import directorio_base
from common.modulos import lectura_json
from src.screens.g_generador_de_collages_2 import ejecutar_generador_collage_2



direccion_disenios = os.path.join(directorio_base,"common","disenios.json")

def ejecutar_seleccionar_imagen_collage(usuario):
        disenio_uno = os.path.join(directorio_base,'src','images','disenios_collages','disenio_uno.png')
        disenio_dos = os.path.join(directorio_base,'src','images','disenios_collages','disenio_dos.png')
        disenio_tres = os.path.join(directorio_base,'src','images','disenios_collages','disenio_tres.png')
        disenio_cuatro = os.path.join(directorio_base,'src','images','disenios_collages','disenio_cuatro.png')

        datos_disenio = lectura_json(direccion_disenios)
        
        layout_disenios = [
        sg.Button(image_source=disenio_uno,size=(50,50),key = '-UNO-'),
        sg.Button(image_source=disenio_dos,size=(50,50),key = '-DOS-'),
        sg.Button(image_source=disenio_tres,size=(50,50),key = '-TRES-'),
        sg.Button(image_source=disenio_cuatro,size=(50,50),key = '-CUATRO-')

        ]

        layout_superior = [
        sg.Text('Seleccionar diseño de collages'),sg.Push(),sg.Button('Volver',key= '-VOLVER-')

        ]

        layout = [
        [
            sg.Column(
                [
                    layout_superior,
                    layout_disenios
                ]
            )
        ]
        ]

        window = sg.Window("UNLPImage-Seleccionar Imagen",layout)

        while True:
            event,values = window.read()
            if event == sg.WIN_CLOSED:
                exit()
            elif event == '-VOLVER-':
                 break
            else:
                 window.hide()
                 match event:
                    case '-UNO-':
                        ejecutar_generador_collage_2(usuario,datos_disenio[0]) 
                    case '-DOS-':
                        ejecutar_generador_collage_2(usuario,datos_disenio[1]) 
                    case '-TRES-':
                        ejecutar_generador_collage_2(usuario,datos_disenio[2])  
                    case '-CUATRO-':
                        ejecutar_generador_collage_2(usuario,datos_disenio[3]) 
                 window.un_hide()              
        window.close()           
