import PySimpleGUI as sg
import os
from PIL import Image
from common.constants import ALTO_WINDOW, ANCH_WINDOW
from .c_menu_principal import ejecutar_menu_principal
from common.constants import directorio_base
from src.screens.b_nuevo_perfil import nuevo_perfil
from common.constants import H1_SIZE
from common.modulos import lectura_json


flecha = os.path.join(directorio_base, 'src', 'images', 'flecha.png')
mas = os.path.join(directorio_base, 'src', 'images', 'mas.png')



def crear_layout_usuarios(usuarios, posicion_actual):
    """Creo el layout de usuarios pasándole como parámetro los usuarios que obtuve del módulo 'traer_usuarios', como máximo se muestran 3 usuarios, si hay más de 3 usuarios creados
     aparece una flecha para mostrar más usuarios, si no hay usuarios en el archivo JSON solo aparece el botón de agregar usuarios, el cual te lleva a la pestaña de crear usuarios. """
    ultimo_usuarios = min(posicion_actual + 3, len(usuarios)) 
    lista_usuarios = usuarios[posicion_actual:ultimo_usuarios]
    if len(usuarios) == 0:
        layout_usuarios = [sg.Text("No hay Perfiles Creados"),sg.Button(image_filename=mas,image_size=(40,40),button_color=(None, sg.theme_background_color()),image_subsample= 3,key='-NUEVO_PERFIL-')]
    else:
        botones_usuarios = []
        for i, usuario in enumerate(lista_usuarios):
                
                imagen_pil = Image.open(usuario["direc_avatar"])
                
                botones_usuarios.append(sg.Button(image_source=usuario["direc_avatar"],
                    image_size=(100,100),
                    image_subsample= 5 if imagen_pil.size >= (400,400) else 0,
                    size=(50,50),
                    key=i,
                    metadata=usuario,
                    tooltip= usuario["nick"]
                    ))
        layout_usuarios = [
            
                
            botones_usuarios    
            ,sg.Button(image_filename=mas,image_size=(50,50),image_subsample= 3,tooltip='Agregar Usuario',key='-NUEVO_PERFIL-')
        ]
        if len(usuarios) > ultimo_usuarios:        
            layout_usuarios.append(
                sg.Button(image_source=flecha,tooltip='Mostrar más Usuarios' ,image_subsample=15,image_size=(50,50), button_color=sg.theme_button_color(), key='-MAS-')
            )
        #nuevo.
        #Sirve para 4to usuario en adelante.  
        if posicion_actual > 2:
            flecha_atras = os.path.join(directorio_base, 'src', 'images', 'flecha_hacia_atras.png')
            layout_usuarios.append(
                sg.Button(image_source=flecha_atras,tooltip='Usuarios anteriores' ,image_subsample=15,image_size=(50,50), button_color=sg.theme_button_color(), key='-ATRAS-')
            )
            
    return layout_usuarios


def crear_ventana(posicion_actual,usuarios):
    """Se crea la ventana que se mostrara"""
    layout_principal = [
         [sg.Text("UNLP Image",font=("",40))],
        crear_layout_usuarios(usuarios,posicion_actual)
        ]

    window = sg.Window('UNLPImage-Inicio', layout_principal, size=(ANCH_WINDOW, ALTO_WINDOW),element_justification= "center", resizable=True, finalize=True)
    
    return window
def ejecutar_inicio():
    
    """Llama a los módulos anteriores para crear el layout principal, cada imagen de usuario al ser cliqueada te llevará al menú principal con la información del usuario"""
    archivo_usuarios = os.path.join(directorio_base, 'src', 'data', 'usuarios.json')
    usuarios = lectura_json(archivo_usuarios)
    posicion_actual = 0
    
    sg.popup("Bienvenido/a a UNLP Image")

    window = crear_ventana(posicion_actual,usuarios)

    while True:
        event, values = window.read()
        
        if type(event) == int:
            window.hide()
            usuario_seleccionado = window[event].metadata
            ejecutar_menu_principal(usuario_seleccionado)
            window.close()
            usuarios = lectura_json(archivo_usuarios)
            posicion_actual = 0
            window = crear_ventana(posicion_actual,usuarios)   

        else:
            match event:
                case sg.WIN_CLOSED:
                    sg.popup("Saliendo de la aplicacion")
                    exit()  

                case '-MAS-':     
                    if posicion_actual+3 < len(usuarios):
                        window.close()
                        posicion_actual += 3                        
                        window = crear_ventana(posicion_actual,usuarios)                          


                case '-ATRAS-':     
                    window.close()
                    posicion_actual -= 3                                                                                                 
                    window = crear_ventana(posicion_actual,usuarios)                          


                case '-NUEVO_PERFIL-':
                    window.hide()
                    nuevo_perfil()
                    window.close()
                    usuarios = lectura_json(archivo_usuarios)
                    posicion_actual = 0                
                    window = crear_ventana(posicion_actual,usuarios)   
    

