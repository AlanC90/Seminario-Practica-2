#UNLPImage.
#Pantalla configuracion.


#Importar modulos.
import PySimpleGUI as sg
import json
import os
import csv
from datetime import datetime
from common.constants import directorio_base, H1_SIZE, TEXT_SIZE, ANCH_WINDOW, ALTO_WINDOW
from common.constants import ruta_archivo_log_sistema
#nuevo
from config.paths import convertir_para_guardar
#-----------


#Inicializaciones.
#-Establecer rutas de archivos de configuracion.
ruta_archi_config_default = os.path.join(directorio_base, "common", "config_directorios_default.json")
ruta_archi_config_modificable= os.path.join(directorio_base, "common", "config_directorios.json")

#-Rutas de carpetas de imagenes.    
dir_general_de_imag = os.path.join(directorio_base, "src", "images")
dir_collage = os.path.join(dir_general_de_imag, "collages")
dir_memes =  os.path.join(dir_general_de_imag, "memes")

#nuevo.
#Rutas relativas.
dir_general_de_imag = convertir_para_guardar(dir_general_de_imag, directorio_base)
dir_collage = convertir_para_guardar(dir_collage, directorio_base)
dir_memes = convertir_para_guardar(dir_memes, directorio_base)



#-Diccionario de rutas de carpetas.
datos= {"DIRECC_REPO_IMAGENES": dir_general_de_imag,
        "DIRECC_DIRECTORIO_COLLAGES": dir_collage,
        "DIRECC_DIRECTORIO_MEMES": dir_memes}      


#-Si archivos "config_default" y "config_modificable" no estan creados, crearlos y cargarlos.
try:
    with open(ruta_archi_config_default, "x") as archi_config_default:
      json.dump(datos, archi_config_default,indent= 4,ensure_ascii= False)

except FileExistsError:
    pass 

try:
    with open(ruta_archi_config_modificable, "x") as archi_config_modificable:      
      json.dump(datos, archi_config_modificable,indent= 4,ensure_ascii= False) 

except FileExistsError:
    pass  


#------------------------------#


#Ventana.
#-Componentes.
def generar_layout(dir_general_de_imag, dir_collage, dir_memes):
    """Funcion que recibe direcciones de carpetas de imagenes, collages y memes, para usarlas como carpetas por
       defecto en los 'FolderBrowse', y retorna los componentes de la ventana."""
    
    #Fila1.
    titulo = sg.Text("Configuracion",
                     size= (15,1),
                     pad=((0,0), (0, 40)), 
                     font = ("Comic Sans MS", H1_SIZE), 
                     key = "-TITULO_CONFIGURACION-")
        
    volver = sg.Button("Volver", 
                       size= (10,1), 
                       pad=((0,0), (0, 40)),
                       font=("Comic Sans MS", 11),
                       key = "-BOTON_VOLVER-")
    
    #------------------------------#   

    
    #Fila2.
    #Columna.
    columna = [
                [sg.Text("Repositorio de imagenes", key= "-SUBTITULO_REPOSITORIO_IMAGENES-")],
                
                [sg.Input(default_text = dir_general_de_imag, key= "-INPUT_DIRECC_REPO_IMAGENES-",disabled= True),
                 sg.FolderBrowse("Seleccionar", initial_folder=dir_general_de_imag)],
                
                [sg.Text("Directorio de collages", key= "-SUBTITULO_DIRECTORIO_COLLAGES-")],

                [sg.Input(default_text = dir_collage, key= "-INPUT_DIRECC_DIRECTORIO_COLLAGES-",disabled= True),
                 sg.FolderBrowse("Seleccionar", initial_folder=dir_general_de_imag)],                                  

                [sg.Text("Directorio de memes", key= "-SUBTITULO_DIRECTORIO_MEMES-")],
                
                [sg.Input(default_text = dir_memes, key= "-INPUT_DIRECC_DIRECTORIO_MEMES-",disabled= True),
                 sg.FolderBrowse("Seleccionar", initial_folder=dir_general_de_imag)],                              

                [sg.Column([[sg.Button("Limpiar", 
                                       font=("Comic Sans MS", 10), 
                                       key= "-BOTON_LIMPIAR-",
                                       pad=((0,0), (31, 0))),
                             sg.Button("Restablecer", 
                                       font=("Comic Sans MS", 10), 
                                       pad=((170,0), (30, 0)), 
                                       key= "-BOTON_RESTABLECER-")]],
                            justification="left")]
                
              ]  
    
    #------------------------------#
    

    #Fila3.    
    guardar = [sg.Push(), sg.Button("Guardar", pad=((0,0), (60, 8)), key= "-BOTON_GUARDAR-")]
    
    #------------------------------#
              

    #layout a retornar.
    layout = [
              [titulo, sg.Push(), volver], 
              [sg.Column(layout= columna, 
                         justification="center",
                         key="-COLUMNA_PRINCIPAL-",                                                                                                 
                         ),                         
               ],                            
              [guardar]              
             ]   

    return layout


    #------------------------------#



def registrar_cambios_config(nick_usuario):
    """Funcion que recibe el nick del usuario cuya sesion esta activa, genera el log correspondiente al cambio 
       en la configuracion de las direcciones de las carpetas de imagenes, y lo registra en el archivo de logs 
       del sistema.      
    """
    
    #Obtener fecha y hora con formato local.
    timestamp = datetime.timestamp(datetime.now())    
    # fecha_hora = datetime.fromtimestamp(timestamp)
    # fecha_hora= fecha_hora.strftime("%d/%m/%Y, %H:%M:%S")
    
    
    #Dato "operacion".
    operacion_realizada= "Cambio en la configuracion del sistema"
     
    
    #Registrar en archivo log del sistema. 
    with open(ruta_archivo_log_sistema, "a")as archivo_csv:
        writer = csv.writer(archivo_csv)        
        writer.writerow([timestamp, nick_usuario, operacion_realizada])


    #------------------------------#



#-Ejecucion.
def ejecutar_configuracion(nick_usuario):
    """Funcion que recibe el nick del usuario cuya sesion esta activa, crea la ventana de configuracion con sus
       componentes y caracteristicas; la ejecuta, procesa los eventos que ocurren, y por ultimo, cierra dicha ventana.
    """

    #Cada vez que se abre la ventana, se muestran los datos de la ultima configuracion.
    #-Abrir archivo de config y cargar datos en variable.
    with open(ruta_archi_config_modificable, "r") as archi_config_modificable:
        datos = json.load(archi_config_modificable)  


    #-Asignar esos datos a variables.
    dir_general_de_imag = datos["DIRECC_REPO_IMAGENES"]
    dir_collage = datos["DIRECC_DIRECTORIO_COLLAGES"]
    dir_memes =  datos["DIRECC_DIRECTORIO_MEMES"]   


    #-Crear ventana.     
    window = sg.Window("UNLPImage-Configuracion", 
                       generar_layout(dir_general_de_imag, dir_collage, dir_memes), 
                       size= (ANCH_WINDOW, ALTO_WINDOW),
                       finalize=True,
                       resizable=True)
    

    #-Establecer tamanio minimo de pantalla.
    window.set_min_size((ANCH_WINDOW, ALTO_WINDOW))

    
    #-Actualizar elementos.
    window["-INPUT_DIRECC_REPO_IMAGENES-"].update(dir_general_de_imag)                    
    window["-INPUT_DIRECC_DIRECTORIO_COLLAGES-"].update(dir_collage)                    
    window["-INPUT_DIRECC_DIRECTORIO_MEMES-"].update(dir_memes) 
    

    #-Bloque while.
    while True:
        #Eventos y valores.
        event, values = window.read()                      
                
        #Acciones segun casos.
        match event:
            case sg.WIN_CLOSED:
                sg.popup("Saliendo de la aplicacion")
                exit()
            

            case "-BOTON_VOLVER-": 
                break

            
            case "-BOTON_LIMPIAR-":    
                #Limpiar valores de inputs.  
                window["-INPUT_DIRECC_REPO_IMAGENES-"].update("")                    
                window["-INPUT_DIRECC_DIRECTORIO_COLLAGES-"].update("")                    
                window["-INPUT_DIRECC_DIRECTORIO_MEMES-"].update("")

                #------------------------------#


            case "-BOTON_RESTABLECER-":                              
                #Leer datos de archivo de configuracion por defecto. 
                with open(ruta_archi_config_default, 'r') as archi_config_default:
                    datos = json.load(archi_config_default)               

                #Actualizar ventana con valores por defecto.                
                window["-INPUT_DIRECC_REPO_IMAGENES-"].update(datos["DIRECC_REPO_IMAGENES"])       
                window["-INPUT_DIRECC_DIRECTORIO_COLLAGES-"].update(datos["DIRECC_DIRECTORIO_COLLAGES"])                    
                window["-INPUT_DIRECC_DIRECTORIO_MEMES-"].update(datos["DIRECC_DIRECTORIO_MEMES"])

                #------------------------------#
                        

            case "-BOTON_GUARDAR-":           
                #Seleccionar datos de interes. 
                datos= list(values.items())
                datos = [datos[0], datos[2], datos[4]]   

                #Mapear removiendo parte del string de los eventos.
                datos = dict(map(lambda elemento: (elemento[0].strip('-INPUT_'), elemento[1]), datos))                     

                #nuevo.
                datos["DIRECC_REPO_IMAGENES"] = convertir_para_guardar(datos["DIRECC_REPO_IMAGENES"], directorio_base)
                datos["DIRECC_DIRECTORIO_COLLAGES"] = convertir_para_guardar(datos["DIRECC_DIRECTORIO_COLLAGES"], directorio_base)
                datos["DIRECC_DIRECTORIO_MEMES"] = convertir_para_guardar(datos["DIRECC_DIRECTORIO_MEMES"], directorio_base)
                
                #Escribir en archivo de configuracion.                 
                with open(ruta_archi_config_modificable, 'w') as archi_config_modificable:                                                                      
                    #Guardar datos en archivo json.
                    json.dump(datos, archi_config_modificable,indent= 4,ensure_ascii= False)
                
                #Informar que se guardaron los datos.
                sg.popup(" Datos guardados ", font=("Comic Sans MS",TEXT_SIZE))

                #Actualizar ventana con valores.                
                window["-INPUT_DIRECC_REPO_IMAGENES-"].update(datos["DIRECC_REPO_IMAGENES"])       
                window["-INPUT_DIRECC_DIRECTORIO_COLLAGES-"].update(datos["DIRECC_DIRECTORIO_COLLAGES"])                    
                window["-INPUT_DIRECC_DIRECTORIO_MEMES-"].update(datos["DIRECC_DIRECTORIO_MEMES"])

                registrar_cambios_config(nick_usuario) 

                #------------------------------#
                                                              


    #-Cerrar ventana.
    window.close()


    #------------------------------#




