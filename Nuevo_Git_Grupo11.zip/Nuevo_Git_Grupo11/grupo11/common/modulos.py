import PySimpleGUI as sg
import json
import csv
from datetime import datetime
import os
from common.constants import directorio_base



def comprobar_campos_completos(ni, nom, g, c, e):
    """funcion que comprueba que ningun campo se encuentre vacío. Recibe como parametros el nick, nombre, genero, correo y edad en ese orden. Retorna True o False"""
    print("comienza el comprobar campos completos")
    aux_campos = (ni, nom, c,)
    for i in aux_campos:
        if not(i == '' or i == ' ') and not(i.startswith(' ')):
          aux = True #usar break point
        else:
            sg.popup("Completar correctamente cada campo.")
            aux = False
            break
    if aux:
        if not (e in range(18,101)):
            aux = False
            sg.popup("La edad debe ser entre 18 y 100 años.")
        elif g == '-Elegir-':
            aux = False
            sg.popup("Seleccione algun genero por favor.")


    return aux



def comprobar_formato_correo(correo):
    """funcion que comprueba si el formato del correo electronico ingresado es correcto. Recibe como parametros el correo y retorna True o False"""
    
    if '@' in correo:
        if correo.endswith(".com") or correo.endswith(".es") or correo.endswith(".ar"):
          return True
        else:
            sg.popup("El correo electronico debe terminar en .com/.ar/.es")
    else:
        sg.popup("el correo electronico no es valido(no contiene @)")
    
    return False


#-------------------MANEJO DE ARCHIVOS JSON----------------------------------------------


def lectura_json(ruta_archivo_json):
    try:
        with open(ruta_archivo_json, 'r') as rut:
            datos = json.load(rut)
    except json.decoder.JSONDecodeError:
        datos = []
    return datos


def escritura_json(datos_a_guardar, ruta_archivo_json):
    se_guardo = False
    try:
        with open(ruta_archivo_json, 'w') as archivo_usuarios:
            json.dump(datos_a_guardar, archivo_usuarios, indent=4)
            se_guardo = True
    except FileNotFoundError:
        sg.popup("No se pudo guardar el usuario ya que el archivo no existe.")       

    return se_guardo


#-------------------LOG DEL SISTEMA----------------------------------------------
def log_sistema (nick_usuario,operacion_realizada,valores = None,textos = None):
    """Funcion recibe nick de usuario cuya sesion esta activa, y el tipo de operacion a registrar.    
            Obtiene fecha y hora actual utilizando modulo datetime.
            Registra evento en archivo log del sistema."""

    #Obtener fecha y hora con formato local.
    timestamp = datetime.timestamp(datetime.now())

    
    #Registrar en archivo de log.
    #-Ruta de archivo donde guardar datos.
    ruta_log = os.path.join(directorio_base,"src","data","logs_sistema.csv")

    #-Escribir datos.
    with open(ruta_log, "a")as archivo_csv:
        writer = csv.writer(archivo_csv)
        writer.writerow([timestamp, nick_usuario, operacion_realizada,valores,textos]) 


